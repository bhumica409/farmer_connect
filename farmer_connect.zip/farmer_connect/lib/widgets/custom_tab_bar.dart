import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Tab item data for custom tab bar
class CustomTabItem {
  final String label;
  final IconData? icon;
  final Widget? customIcon;
  final String? route;

  const CustomTabItem({
    required this.label,
    this.icon,
    this.customIcon,
    this.route,
  });
}

/// Custom Tab Bar for agricultural application sections
/// Provides secondary navigation within specific app areas
class CustomTabBar extends StatelessWidget implements PreferredSizeWidget {
  final List<CustomTabItem> tabs;
  final TabController? controller;
  final ValueChanged<int>? onTap;
  final bool isScrollable;
  final Color? backgroundColor;
  final Color? indicatorColor;
  final Color? labelColor;
  final Color? unselectedLabelColor;
  final double indicatorWeight;
  final EdgeInsetsGeometry? labelPadding;
  final EdgeInsetsGeometry? padding;

  const CustomTabBar({
    super.key,
    required this.tabs,
    this.controller,
    this.onTap,
    this.isScrollable = false,
    this.backgroundColor,
    this.indicatorColor,
    this.labelColor,
    this.unselectedLabelColor,
    this.indicatorWeight = 3.0,
    this.labelPadding,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      color: backgroundColor ?? theme.colorScheme.surface,
      padding: padding ?? EdgeInsets.zero,
      child: TabBar(
        controller: controller,
        onTap: onTap,
        isScrollable: isScrollable,
        indicatorColor: indicatorColor ?? theme.colorScheme.primary,
        indicatorWeight: indicatorWeight,
        indicatorSize: TabBarIndicatorSize.label,
        labelColor: labelColor ?? theme.colorScheme.primary,
        unselectedLabelColor: unselectedLabelColor ??
            theme.colorScheme.onSurface.withValues(alpha: 0.6),
        labelPadding: labelPadding ?? EdgeInsets.symmetric(horizontal: 16),
        labelStyle: GoogleFonts.roboto(
          fontSize: 14,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.5,
        ),
        unselectedLabelStyle: GoogleFonts.roboto(
          fontSize: 14,
          fontWeight: FontWeight.w400,
          letterSpacing: 0.5,
        ),
        tabs: tabs.map((tab) => _buildTab(tab, theme)).toList(),
      ),
    );
  }

  Widget _buildTab(CustomTabItem tab, ThemeData theme) {
    if (tab.icon != null || tab.customIcon != null) {
      return Tab(
        icon: tab.customIcon ??
            Icon(
              tab.icon,
              size: 20,
            ),
        text: tab.label,
        height: 72,
      );
    } else {
      return Tab(
        text: tab.label,
        height: 48,
      );
    }
  }

  @override
  Size get preferredSize {
    // Determine height based on whether tabs have icons
    final hasIcons =
        tabs.any((tab) => tab.icon != null || tab.customIcon != null);
    final height = hasIcons ? 72.0 : 48.0;
    return Size.fromHeight(height + (padding?.vertical ?? 0));
  }
}

/// Segmented Tab Bar for binary choices (like Indoor/Outdoor farming)
class CustomSegmentedTabBar extends StatelessWidget {
  final List<String> segments;
  final int selectedIndex;
  final ValueChanged<int>? onSelectionChanged;
  final Color? backgroundColor;
  final Color? selectedColor;
  final Color? unselectedColor;
  final EdgeInsetsGeometry? padding;
  final EdgeInsetsGeometry? margin;

  const CustomSegmentedTabBar({
    super.key,
    required this.segments,
    required this.selectedIndex,
    this.onSelectionChanged,
    this.backgroundColor,
    this.selectedColor,
    this.unselectedColor,
    this.padding,
    this.margin,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: margin ?? EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      padding: EdgeInsets.all(4),
      decoration: BoxDecoration(
        color: backgroundColor ?? theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: theme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: segments.asMap().entries.map((entry) {
          final index = entry.key;
          final segment = entry.value;
          final isSelected = index == selectedIndex;

          return Expanded(
            child: GestureDetector(
              onTap: () => onSelectionChanged?.call(index),
              child: AnimatedContainer(
                duration: Duration(milliseconds: 200),
                padding: padding ??
                    EdgeInsets.symmetric(vertical: 12, horizontal: 16),
                decoration: BoxDecoration(
                  color: isSelected
                      ? selectedColor ?? theme.colorScheme.primary
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  segment,
                  textAlign: TextAlign.center,
                  style: GoogleFonts.roboto(
                    fontSize: 14,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                    color: isSelected
                        ? theme.colorScheme.onPrimary
                        : unselectedColor ?? theme.colorScheme.onSurface,
                    letterSpacing: 0.25,
                  ),
                ),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

/// Chip-style Tab Bar for multiple filter options
class CustomChipTabBar extends StatelessWidget {
  final List<String> chips;
  final List<int> selectedIndices;
  final ValueChanged<List<int>>? onSelectionChanged;
  final bool multiSelect;
  final Color? backgroundColor;
  final Color? selectedColor;
  final Color? unselectedColor;
  final EdgeInsetsGeometry? padding;
  final double spacing;
  final double runSpacing;

  const CustomChipTabBar({
    super.key,
    required this.chips,
    required this.selectedIndices,
    this.onSelectionChanged,
    this.multiSelect = true,
    this.backgroundColor,
    this.selectedColor,
    this.unselectedColor,
    this.padding,
    this.spacing = 8.0,
    this.runSpacing = 8.0,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: padding ?? EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Wrap(
        spacing: spacing,
        runSpacing: runSpacing,
        children: chips.asMap().entries.map((entry) {
          final index = entry.key;
          final chip = entry.value;
          final isSelected = selectedIndices.contains(index);

          return FilterChip(
            label: Text(
              chip,
              style: GoogleFonts.roboto(
                fontSize: 12,
                fontWeight: isSelected ? FontWeight.w500 : FontWeight.w400,
                color: isSelected
                    ? theme.colorScheme.onPrimary
                    : unselectedColor ?? theme.colorScheme.onSurface,
                letterSpacing: 0.4,
              ),
            ),
            selected: isSelected,
            onSelected: (selected) {
              List<int> newSelection = List.from(selectedIndices);

              if (multiSelect) {
                if (selected) {
                  newSelection.add(index);
                } else {
                  newSelection.remove(index);
                }
              } else {
                newSelection = selected ? [index] : [];
              }

              onSelectionChanged?.call(newSelection);
            },
            backgroundColor: backgroundColor ?? theme.colorScheme.surface,
            selectedColor: selectedColor ?? theme.colorScheme.primary,
            checkmarkColor: theme.colorScheme.onPrimary,
            side: BorderSide(
              color: isSelected
                  ? selectedColor ?? theme.colorScheme.primary
                  : theme.colorScheme.outline.withValues(alpha: 0.3),
              width: 1,
            ),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          );
        }).toList(),
      ),
    );
  }
}

/// Predefined tab configurations for agricultural app sections
class AgricultureTabConfigs {
  // Weather forecast tabs
  static const List<CustomTabItem> weatherTabs = [
    CustomTabItem(label: 'Today', icon: Icons.today),
    CustomTabItem(label: '7 Days', icon: Icons.calendar_view_week),
    CustomTabItem(label: 'Monthly', icon: Icons.calendar_month),
  ];

  // Crop management tabs
  static const List<CustomTabItem> cropTabs = [
    CustomTabItem(label: 'Prices', icon: Icons.trending_up),
    CustomTabItem(label: 'Market', icon: Icons.store),
    CustomTabItem(label: 'Analysis', icon: Icons.analytics),
  ];

  // Government schemes tabs
  static const List<CustomTabItem> schemeTabs = [
    CustomTabItem(label: 'Active', icon: Icons.check_circle_outline),
    CustomTabItem(label: 'Upcoming', icon: Icons.schedule),
    CustomTabItem(label: 'Archived', icon: Icons.archive_outlined),
  ];

  // Forum discussion tabs
  static const List<CustomTabItem> forumTabs = [
    CustomTabItem(label: 'Recent', icon: Icons.access_time),
    CustomTabItem(label: 'Popular', icon: Icons.trending_up),
    CustomTabItem(label: 'My Posts', icon: Icons.person),
  ];

  // Profile settings tabs
  static const List<CustomTabItem> profileTabs = [
    CustomTabItem(label: 'Account', icon: Icons.account_circle),
    CustomTabItem(label: 'Preferences', icon: Icons.settings),
    CustomTabItem(label: 'Help', icon: Icons.help_outline),
  ];
}
