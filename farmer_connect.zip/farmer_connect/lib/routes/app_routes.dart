import 'package:flutter/material.dart';
import '../presentation/farmer_discussion_forum/farmer_discussion_forum.dart';
import '../presentation/weather_forecast/weather_forecast.dart';
import '../presentation/pdf_document_viewer/pdf_document_viewer.dart';
import '../presentation/crop_price_search/crop_price_search.dart';
import '../presentation/user_profile_settings/user_profile_settings.dart';
import '../presentation/government_schemes_browser/government_schemes_browser.dart';

class AppRoutes {
  // TODO: Add your routes here
  static const String initial = '/';
  static const String farmerDiscussionForum = '/farmer-discussion-forum';
  static const String weatherForecast = '/weather-forecast';
  static const String pdfDocumentViewer = '/pdf-document-viewer';
  static const String cropPriceSearch = '/crop-price-search';
  static const String userProfileSettings = '/user-profile-settings';
  static const String governmentSchemesBrowser = '/government-schemes-browser';

  static Map<String, WidgetBuilder> routes = {
    initial: (context) => const FarmerDiscussionForum(),
    farmerDiscussionForum: (context) => const FarmerDiscussionForum(),
    weatherForecast: (context) => const WeatherForecast(),
    pdfDocumentViewer: (context) => const PdfDocumentViewer(),
    cropPriceSearch: (context) => const CropPriceSearch(),
    userProfileSettings: (context) => const UserProfileSettings(),
    governmentSchemesBrowser: (context) => const GovernmentSchemesBrowser(),
    // TODO: Add your other routes here
  };
}
