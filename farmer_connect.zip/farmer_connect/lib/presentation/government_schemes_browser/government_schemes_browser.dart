import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import '../../widgets/custom_app_bar.dart';
import '../../widgets/custom_bottom_bar.dart';
import './widgets/eligibility_checker_fab.dart';
import './widgets/filter_modal.dart';
import './widgets/scheme_card.dart';
import './widgets/scheme_category_chips.dart';

class GovernmentSchemesBrowser extends StatefulWidget {
  const GovernmentSchemesBrowser({super.key});

  @override
  State<GovernmentSchemesBrowser> createState() =>
      _GovernmentSchemesBrowserState();
}

class _GovernmentSchemesBrowserState extends State<GovernmentSchemesBrowser> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  String _selectedCategory = 'All';
  List<String> _bookmarkedSchemes = [];
  bool _isLoading = false;
  String _searchQuery = '';

  Map<String, dynamic> _filters = {
    'state': 'All States',
    'district': '',
    'schemeType': 'All Types',
    'minAmount': 0.0,
    'maxAmount': 1000000.0,
  };

  final List<String> _categories = [
    'All',
    'Crop Insurance',
    'Equipment Subsidies',
    'Organic Farming',
    'Loans',
    'Training'
  ];

  final List<Map<String, dynamic>> _allSchemes = [
    {
      'id': '1',
      'name': 'Pradhan Mantri Fasal Bima Yojana',
      'department': 'Ministry of Agriculture & Farmers Welfare',
      'category': 'Crop Insurance',
      'eligibilitySummary':
          'All farmers growing notified crops in notified areas are eligible',
      'benefitAmount': '₹2,00,000 per hectare',
      'daysLeft': 15,
      'state': 'All States',
      'fullDetails':
          'The Pradhan Mantri Fasal Bima Yojana (PMFBY) provides comprehensive insurance coverage against crop loss to farmers. The scheme covers all food crops, oilseeds, and annual commercial/horticultural crops for which past yield data is available.',
      'requiredDocuments': [
        'Aadhaar Card',
        'Land Records (Khatauni/Khesra)',
        'Bank Account Details',
        'Sowing Certificate',
        'Previous Year Yield Certificate'
      ],
      'applicationSteps': [
        'Visit nearest Common Service Center or Bank',
        'Fill the application form with required details',
        'Submit documents and pay premium',
        'Get acknowledgment receipt',
        'Policy will be issued within 7 days'
      ]
    },
    {
      'id': '2',
      'name': 'Sub-Mission on Agricultural Mechanization',
      'department': 'Department of Agriculture & Cooperation',
      'category': 'Equipment Subsidies',
      'eligibilitySummary':
          'Small and marginal farmers, SC/ST farmers, women farmers eligible',
      'benefitAmount': '₹80,000 subsidy',
      'daysLeft': 45,
      'state': 'All States',
      'fullDetails':
          'This scheme promotes farm mechanization through financial assistance for purchase of agricultural machinery and equipment. Priority is given to small farmers, SC/ST farmers, and women farmers.',
      'requiredDocuments': [
        'Aadhaar Card',
        'Land Ownership Certificate',
        'Income Certificate',
        'Caste Certificate (if applicable)',
        'Bank Account Details'
      ],
      'applicationSteps': [
        'Register on official portal',
        'Select desired machinery from approved list',
        'Submit online application with documents',
        'Get approval from district collector',
        'Purchase machinery from authorized dealer',
        'Submit bills for subsidy claim'
      ]
    },
    {
      'id': '3',
      'name': 'Paramparagat Krishi Vikas Yojana',
      'department': 'Ministry of Agriculture & Farmers Welfare',
      'category': 'Organic Farming',
      'eligibilitySummary':
          'Farmers willing to adopt organic farming practices in clusters',
      'benefitAmount': '₹50,000 per hectare',
      'daysLeft': 30,
      'state': 'All States',
      'fullDetails':
          'PKVY promotes organic farming through cluster-based approach. It provides financial assistance for organic inputs, certification, and marketing support to farmers adopting organic farming practices.',
      'requiredDocuments': [
        'Aadhaar Card',
        'Land Records',
        'Soil Health Card',
        'Group Formation Certificate',
        'Bank Account Details'
      ],
      'applicationSteps': [
        'Form farmer groups of 20 farmers minimum',
        'Apply through State Agriculture Department',
        'Get cluster approval for organic farming',
        'Attend training programs',
        'Start organic farming practices',
        'Get organic certification after 3 years'
      ]
    },
    {
      'id': '4',
      'name': 'Kisan Credit Card Scheme',
      'department': 'Department of Financial Services',
      'category': 'Loans',
      'eligibilitySummary':
          'All farmers including tenant farmers and sharecroppers eligible',
      'benefitAmount': '₹3,00,000 credit limit',
      'daysLeft': 60,
      'state': 'All States',
      'fullDetails':
          'KCC provides adequate and timely credit support to farmers for their cultivation and other needs. The scheme covers crop loans, term loans for agriculture investments, and consumption needs.',
      'requiredDocuments': [
        'Aadhaar Card',
        'Land Documents',
        'Income Proof',
        'Passport Size Photos',
        'Bank Account Details'
      ],
      'applicationSteps': [
        'Visit nearest bank branch',
        'Fill KCC application form',
        'Submit required documents',
        'Bank verification and assessment',
        'Credit limit sanctioned',
        'KCC issued within 15 days'
      ]
    },
    {
      'id': '5',
      'name': 'National Mission for Sustainable Agriculture',
      'department': 'Ministry of Agriculture & Farmers Welfare',
      'category': 'Training',
      'eligibilitySummary':
          'All farmers interested in sustainable agriculture practices',
      'benefitAmount': '₹25,000 training support',
      'daysLeft': 90,
      'state': 'All States',
      'fullDetails':
          'NMSA promotes sustainable agriculture through climate-resilient practices, soil health management, and efficient water use. It provides training and financial support for adopting sustainable farming techniques.',
      'requiredDocuments': [
        'Aadhaar Card',
        'Land Records',
        'Educational Qualification Certificate',
        'Bank Account Details',
        'Mobile Number'
      ],
      'applicationSteps': [
        'Register on NMSA portal',
        'Select training program',
        'Submit online application',
        'Attend selection process',
        'Complete training program',
        'Receive certificate and financial support'
      ]
    },
    {
      'id': '6',
      'name': 'Micro Irrigation Fund',
      'department': 'NABARD',
      'category': 'Equipment Subsidies',
      'eligibilitySummary':
          'Farmers adopting micro irrigation systems like drip and sprinkler',
      'benefitAmount': '₹1,00,000 subsidy',
      'daysLeft': 20,
      'state': 'All States',
      'fullDetails':
          'The Micro Irrigation Fund supports farmers in adopting water-efficient irrigation systems. It provides financial assistance for installation of drip irrigation, sprinkler systems, and other micro irrigation technologies.',
      'requiredDocuments': [
        'Aadhaar Card',
        'Land Ownership Documents',
        'Water Source Certificate',
        'Technical Feasibility Report',
        'Bank Account Details'
      ],
      'applicationSteps': [
        'Get technical assessment done',
        'Apply through State Horticulture Department',
        'Submit detailed project report',
        'Get technical and financial approval',
        'Install system through approved vendor',
        'Claim subsidy after installation'
      ]
    }
  ];

  List<Map<String, dynamic>> get _filteredSchemes {
    List<Map<String, dynamic>> filtered = _allSchemes;

    // Filter by category
    if (_selectedCategory != 'All') {
      filtered = filtered
          .where((scheme) => scheme['category'] == _selectedCategory)
          .toList();
    }

    // Filter by search query
    if (_searchQuery.isNotEmpty) {
      filtered = filtered
          .where((scheme) =>
              (scheme['name'] as String)
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase()) ||
              (scheme['eligibilitySummary'] as String)
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase()) ||
              (scheme['department'] as String)
                  .toLowerCase()
                  .contains(_searchQuery.toLowerCase()))
          .toList();
    }

    // Apply advanced filters
    if (_filters['state'] != 'All States') {
      filtered = filtered
          .where((scheme) =>
              scheme['state'] == _filters['state'] ||
              scheme['state'] == 'All States')
          .toList();
    }

    if (_filters['schemeType'] != 'All Types') {
      filtered = filtered
          .where((scheme) => scheme['category'] == _filters['schemeType'])
          .toList();
    }

    return filtered;
  }

  @override
  void initState() {
    super.initState();
    _refreshSchemes();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _refreshSchemes() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(Duration(seconds: 1));

    setState(() {
      _isLoading = false;
    });

    Fluttertoast.showToast(
      msg: "Schemes updated successfully",
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
    );
  }

  void _onCategorySelected(String category) {
    setState(() {
      _selectedCategory = category;
    });
  }

  void _onSearchChanged(String query) {
    setState(() {
      _searchQuery = query;
    });
  }

  void _toggleBookmark(String schemeId) {
    setState(() {
      if (_bookmarkedSchemes.contains(schemeId)) {
        _bookmarkedSchemes.remove(schemeId);
        Fluttertoast.showToast(msg: "Removed from bookmarks");
      } else {
        _bookmarkedSchemes.add(schemeId);
        Fluttertoast.showToast(msg: "Added to bookmarks");
      }
    });
  }

  void _shareScheme(Map<String, dynamic> scheme) {
    Fluttertoast.showToast(
      msg: "Sharing ${scheme['name']}",
      toastLength: Toast.LENGTH_SHORT,
    );
  }

  void _saveSchemePdf(Map<String, dynamic> scheme) {
    Fluttertoast.showToast(
      msg: "PDF saved for ${scheme['name']}",
      toastLength: Toast.LENGTH_SHORT,
    );
  }

  void _setReminder(Map<String, dynamic> scheme) {
    Fluttertoast.showToast(
      msg: "Reminder set for ${scheme['name']}",
      toastLength: Toast.LENGTH_SHORT,
    );
  }

  void _showFilterModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterModal(
        currentFilters: _filters,
        onFiltersChanged: (newFilters) {
          setState(() {
            _filters = newFilters;
          });
        },
      ),
    );
  }

  void _showEligibilityChecker() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => EligibilityCheckerModal(),
    );
  }

  void _showBookmarks() {
    final bookmarkedSchemesList = _allSchemes
        .where((scheme) => _bookmarkedSchemes.contains(scheme['id']))
        .toList();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: 80.h,
        decoration: BoxDecoration(
          color: AppTheme.lightTheme.colorScheme.surface,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            topRight: Radius.circular(20),
          ),
        ),
        child: Column(
          children: [
            Container(
              width: 12.w,
              height: 0.5.h,
              margin: EdgeInsets.only(top: 1.h),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.onSurface
                    .withValues(alpha: 0.3),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(4.w),
              child: Text(
                'Bookmarked Schemes',
                style: TextStyle(
                  fontSize: 18.sp,
                  fontWeight: FontWeight.w600,
                  color: AppTheme.lightTheme.colorScheme.onSurface,
                ),
              ),
            ),
            Expanded(
              child: bookmarkedSchemesList.isEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CustomIconWidget(
                            iconName: 'bookmark_border',
                            color: AppTheme.lightTheme.colorScheme.onSurface
                                .withValues(alpha: 0.4),
                            size: 15.w,
                          ),
                          SizedBox(height: 2.h),
                          Text(
                            'No bookmarked schemes',
                            style: TextStyle(
                              fontSize: 14.sp,
                              color: AppTheme.lightTheme.colorScheme.onSurface
                                  .withValues(alpha: 0.6),
                            ),
                          ),
                        ],
                      ),
                    )
                  : ListView.builder(
                      itemCount: bookmarkedSchemesList.length,
                      itemBuilder: (context, index) {
                        final scheme = bookmarkedSchemesList[index];
                        return SchemeCard(
                          scheme: scheme,
                          isBookmarked: true,
                          onBookmarkToggle: () => _toggleBookmark(scheme['id']),
                          onShare: () => _shareScheme(scheme),
                          onSavePdf: () => _saveSchemePdf(scheme),
                          onSetReminder: () => _setReminder(scheme),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: CustomAppBar(
        title: 'Government Schemes',
        actions: [
          IconButton(
            onPressed: _showBookmarks,
            icon: CustomIconWidget(
              iconName: 'favorite',
              color: AppTheme.lightTheme.appBarTheme.foregroundColor!,
              size: 6.w,
            ),
            tooltip: 'Bookmarks',
          ),
          IconButton(
            onPressed: _showFilterModal,
            icon: CustomIconWidget(
              iconName: 'filter_list',
              color: AppTheme.lightTheme.appBarTheme.foregroundColor!,
              size: 6.w,
            ),
            tooltip: 'Filter',
          ),
          SizedBox(width: 2.w),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _refreshSchemes,
        color: AppTheme.lightTheme.colorScheme.primary,
        child: Column(
          children: [
            // Search bar
            Container(
              padding: EdgeInsets.all(4.w),
              child: TextField(
                controller: _searchController,
                onChanged: _onSearchChanged,
                decoration: InputDecoration(
                  hintText: 'Search schemes, keywords, crop types...',
                  prefixIcon: Padding(
                    padding: EdgeInsets.all(3.w),
                    child: CustomIconWidget(
                      iconName: 'search',
                      color: AppTheme.lightTheme.colorScheme.onSurface
                          .withValues(alpha: 0.6),
                      size: 5.w,
                    ),
                  ),
                  suffixIcon: _searchQuery.isNotEmpty
                      ? IconButton(
                          onPressed: () {
                            _searchController.clear();
                            _onSearchChanged('');
                          },
                          icon: CustomIconWidget(
                            iconName: 'clear',
                            color: AppTheme.lightTheme.colorScheme.onSurface
                                .withValues(alpha: 0.6),
                            size: 5.w,
                          ),
                        )
                      : null,
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                    ),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: AppTheme.lightTheme.colorScheme.outline
                          .withValues(alpha: 0.3),
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide(
                      color: AppTheme.lightTheme.colorScheme.primary,
                      width: 2,
                    ),
                  ),
                  filled: true,
                  fillColor: AppTheme.lightTheme.colorScheme.surface,
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
                ),
              ),
            ),

            // Category chips
            SchemeCategoryChips(
              categories: _categories,
              selectedCategory: _selectedCategory,
              onCategorySelected: _onCategorySelected,
            ),

            // Schemes list
            Expanded(
              child: _isLoading
                  ? Center(
                      child: CircularProgressIndicator(
                        color: AppTheme.lightTheme.colorScheme.primary,
                      ),
                    )
                  : _filteredSchemes.isEmpty
                      ? Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              CustomIconWidget(
                                iconName: 'search_off',
                                color: AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.4),
                                size: 15.w,
                              ),
                              SizedBox(height: 2.h),
                              Text(
                                'No schemes found',
                                style: TextStyle(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w500,
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurface
                                      .withValues(alpha: 0.6),
                                ),
                              ),
                              SizedBox(height: 1.h),
                              Text(
                                'Try adjusting your search or filters',
                                style: TextStyle(
                                  fontSize: 12.sp,
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurface
                                      .withValues(alpha: 0.5),
                                ),
                              ),
                            ],
                          ),
                        )
                      : ListView.builder(
                          controller: _scrollController,
                          padding: EdgeInsets.only(bottom: 10.h),
                          itemCount: _filteredSchemes.length,
                          itemBuilder: (context, index) {
                            final scheme = _filteredSchemes[index];
                            return SchemeCard(
                              scheme: scheme,
                              isBookmarked:
                                  _bookmarkedSchemes.contains(scheme['id']),
                              onBookmarkToggle: () =>
                                  _toggleBookmark(scheme['id']),
                              onShare: () => _shareScheme(scheme),
                              onSavePdf: () => _saveSchemePdf(scheme),
                              onSetReminder: () => _setReminder(scheme),
                            );
                          },
                        ),
            ),
          ],
        ),
      ),
      floatingActionButton: EligibilityCheckerFAB(
        onPressed: _showEligibilityChecker,
      ),
      bottomNavigationBar: CustomBottomBar(
        currentIndex: 2,
        onTap: (index) {
          final route = CustomBottomBar.getRouteForIndex(index);
          if (route != '/government-schemes-browser') {
            Navigator.pushReplacementNamed(context, route);
          }
        },
      ),
    );
  }
}
