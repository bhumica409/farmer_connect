import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class EligibilityCheckerFAB extends StatelessWidget {
  final VoidCallback onPressed;

  const EligibilityCheckerFAB({
    super.key,
    required this.onPressed,
  });

  @override
  Widget build(BuildContext context) {
    return FloatingActionButton.extended(
      onPressed: onPressed,
      backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
      foregroundColor: AppTheme.lightTheme.colorScheme.onTertiary,
      elevation: 4.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16.0),
      ),
      icon: CustomIconWidget(
        iconName: 'quiz',
        color: AppTheme.lightTheme.colorScheme.onTertiary,
        size: 5.w,
      ),
      label: Text(
        'Check Eligibility',
        style: TextStyle(
          fontSize: 12.sp,
          fontWeight: FontWeight.w600,
          letterSpacing: 0.25,
        ),
      ),
    );
  }
}

class EligibilityCheckerModal extends StatefulWidget {
  const EligibilityCheckerModal({super.key});

  @override
  State<EligibilityCheckerModal> createState() =>
      _EligibilityCheckerModalState();
}

class _EligibilityCheckerModalState extends State<EligibilityCheckerModal> {
  int _currentQuestionIndex = 0;
  Map<String, dynamic> _answers = {};

  final List<Map<String, dynamic>> _questions = [
    {
      'id': 'farmSize',
      'question': 'What is your farm size?',
      'type': 'single',
      'options': [
        'Less than 1 acre',
        '1-2 acres',
        '2-5 acres',
        '5-10 acres',
        'More than 10 acres'
      ],
    },
    {
      'id': 'cropType',
      'question': 'What type of crops do you grow?',
      'type': 'multiple',
      'options': [
        'Rice',
        'Wheat',
        'Cotton',
        'Sugarcane',
        'Vegetables',
        'Fruits',
        'Pulses'
      ],
    },
    {
      'id': 'annualIncome',
      'question': 'What is your annual household income?',
      'type': 'single',
      'options': ['Below ₹2 lakh', '₹2-5 lakh', '₹5-10 lakh', 'Above ₹10 lakh'],
    },
    {
      'id': 'landOwnership',
      'question': 'What is your land ownership status?',
      'type': 'single',
      'options': ['Own land', 'Leased land', 'Sharecropper', 'Tenant farmer'],
    },
    {
      'id': 'age',
      'question': 'What is your age group?',
      'type': 'single',
      'options': [
        '18-25 years',
        '26-35 years',
        '36-50 years',
        '51-60 years',
        'Above 60 years'
      ],
    },
  ];

  void _nextQuestion() {
    if (_currentQuestionIndex < _questions.length - 1) {
      setState(() {
        _currentQuestionIndex++;
      });
    } else {
      _showResults();
    }
  }

  void _previousQuestion() {
    if (_currentQuestionIndex > 0) {
      setState(() {
        _currentQuestionIndex--;
      });
    }
  }

  void _selectAnswer(String questionId, dynamic answer) {
    setState(() {
      _answers[questionId] = answer;
    });
  }

  void _showResults() {
    final eligibleSchemes = _calculateEligibleSchemes();

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(
          'Eligibility Results',
          style: TextStyle(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Based on your answers, you are eligible for:',
              style: TextStyle(
                fontSize: 12.sp,
                fontWeight: FontWeight.w400,
              ),
            ),
            SizedBox(height: 2.h),
            ...eligibleSchemes
                .map((scheme) => Padding(
                      padding: EdgeInsets.only(bottom: 1.h),
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'check_circle',
                            color: AppTheme.lightTheme.colorScheme.primary,
                            size: 4.w,
                          ),
                          SizedBox(width: 2.w),
                          Expanded(
                            child: Text(
                              scheme,
                              style: TextStyle(
                                fontSize: 11.sp,
                                fontWeight: FontWeight.w400,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ))
                .toList(),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
            },
            child: Text('Close'),
          ),
        ],
      ),
    );
  }

  List<String> _calculateEligibleSchemes() {
    List<String> schemes = [];

    // Simple eligibility logic based on answers
    final farmSize = _answers['farmSize'] as String?;
    final income = _answers['annualIncome'] as String?;
    final cropType = _answers['cropType'] as List<String>?;

    if (farmSize == 'Less than 1 acre' || farmSize == '1-2 acres') {
      schemes.add('Small Farmer Equipment Subsidy');
      schemes.add('Micro Irrigation Scheme');
    }

    if (income == 'Below ₹2 lakh' || income == '₹2-5 lakh') {
      schemes.add('Pradhan Mantri Kisan Samman Nidhi');
      schemes.add('Crop Insurance Scheme');
    }

    if (cropType?.contains('Organic') == true ||
        cropType?.contains('Vegetables') == true) {
      schemes.add('Organic Farming Promotion Scheme');
      schemes.add('Vegetable Cluster Development');
    }

    if (schemes.isEmpty) {
      schemes.add('General Agricultural Development Scheme');
      schemes.add('Farmer Training Program');
    }

    return schemes;
  }

  @override
  Widget build(BuildContext context) {
    final currentQuestion = _questions[_currentQuestionIndex];
    final progress = (_currentQuestionIndex + 1) / _questions.length;

    return Container(
      height: 70.h,
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(20),
          topRight: Radius.circular(20),
        ),
      ),
      child: Column(
        children: [
          // Handle bar
          Container(
            width: 12.w,
            height: 0.5.h,
            margin: EdgeInsets.only(top: 1.h),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.onSurface
                  .withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // Header with progress
          Padding(
            padding: EdgeInsets.all(4.w),
            child: Column(
              children: [
                Row(
                  children: [
                    Text(
                      'Eligibility Checker',
                      style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w600,
                        color: AppTheme.lightTheme.colorScheme.onSurface,
                      ),
                    ),
                    Spacer(),
                    Text(
                      '${_currentQuestionIndex + 1}/${_questions.length}',
                      style: TextStyle(
                        fontSize: 12.sp,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.lightTheme.colorScheme.onSurface
                            .withValues(alpha: 0.7),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 2.h),
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                  valueColor: AlwaysStoppedAnimation<Color>(
                    AppTheme.lightTheme.colorScheme.primary,
                  ),
                ),
              ],
            ),
          ),

          Expanded(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 4.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Question
                  Text(
                    currentQuestion['question'] as String,
                    style: TextStyle(
                      fontSize: 16.sp,
                      fontWeight: FontWeight.w600,
                      color: AppTheme.lightTheme.colorScheme.onSurface,
                      height: 1.4,
                    ),
                  ),
                  SizedBox(height: 3.h),

                  // Options
                  Expanded(
                    child: ListView.builder(
                      itemCount:
                          (currentQuestion['options'] as List<String>).length,
                      itemBuilder: (context, index) {
                        final option =
                            (currentQuestion['options'] as List<String>)[index];
                        final isSelected = currentQuestion['type'] == 'single'
                            ? _answers[currentQuestion['id']] == option
                            : (_answers[currentQuestion['id']] as List<String>?)
                                    ?.contains(option) ??
                                false;

                        return GestureDetector(
                          onTap: () {
                            if (currentQuestion['type'] == 'single') {
                              _selectAnswer(currentQuestion['id'], option);
                            } else {
                              List<String> currentAnswers = List<String>.from(
                                  _answers[currentQuestion['id']]
                                          as List<String>? ??
                                      []);
                              if (currentAnswers.contains(option)) {
                                currentAnswers.remove(option);
                              } else {
                                currentAnswers.add(option);
                              }
                              _selectAnswer(
                                  currentQuestion['id'], currentAnswers);
                            }
                          },
                          child: Container(
                            margin: EdgeInsets.only(bottom: 2.h),
                            padding: EdgeInsets.all(4.w),
                            decoration: BoxDecoration(
                              color: isSelected
                                  ? AppTheme.lightTheme.colorScheme.primary
                                      .withValues(alpha: 0.1)
                                  : AppTheme.lightTheme.colorScheme.surface,
                              border: Border.all(
                                color: isSelected
                                    ? AppTheme.lightTheme.colorScheme.primary
                                    : AppTheme.lightTheme.colorScheme.outline
                                        .withValues(alpha: 0.3),
                                width: isSelected ? 2 : 1,
                              ),
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Row(
                              children: [
                                CustomIconWidget(
                                  iconName: currentQuestion['type'] == 'single'
                                      ? (isSelected
                                          ? 'radio_button_checked'
                                          : 'radio_button_unchecked')
                                      : (isSelected
                                          ? 'check_box'
                                          : 'check_box_outline_blank'),
                                  color: isSelected
                                      ? AppTheme.lightTheme.colorScheme.primary
                                      : AppTheme
                                          .lightTheme.colorScheme.onSurface
                                          .withValues(alpha: 0.6),
                                  size: 5.w,
                                ),
                                SizedBox(width: 3.w),
                                Expanded(
                                  child: Text(
                                    option,
                                    style: TextStyle(
                                      fontSize: 13.sp,
                                      fontWeight: FontWeight.w400,
                                      color: AppTheme
                                          .lightTheme.colorScheme.onSurface,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),

          // Navigation buttons
          Container(
            padding: EdgeInsets.all(4.w),
            child: Row(
              children: [
                if (_currentQuestionIndex > 0)
                  Expanded(
                    child: OutlinedButton(
                      onPressed: _previousQuestion,
                      child: Text('Previous'),
                    ),
                  ),
                if (_currentQuestionIndex > 0) SizedBox(width: 3.w),
                Expanded(
                  child: ElevatedButton(
                    onPressed: _answers.containsKey(currentQuestion['id'])
                        ? _nextQuestion
                        : null,
                    child: Text(
                      _currentQuestionIndex == _questions.length - 1
                          ? 'Get Results'
                          : 'Next',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
