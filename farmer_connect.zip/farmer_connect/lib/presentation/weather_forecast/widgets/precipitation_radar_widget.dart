import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PrecipitationRadarWidget extends StatefulWidget {
  final Map<String, dynamic> radarData;

  const PrecipitationRadarWidget({
    super.key,
    required this.radarData,
  });

  @override
  State<PrecipitationRadarWidget> createState() =>
      _PrecipitationRadarWidgetState();
}

class _PrecipitationRadarWidgetState extends State<PrecipitationRadarWidget> {
  double _zoomLevel = 1.0;
  Offset _panOffset = Offset.zero;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 40.h,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header with controls
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Precipitation Radar',
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      onPressed: _zoomIn,
                      icon: CustomIconWidget(
                        iconName: 'zoom_in',
                        color: AppTheme.lightTheme.colorScheme.primary,
                        size: 6.w,
                      ),
                      tooltip: 'Zoom In',
                    ),
                    IconButton(
                      onPressed: _zoomOut,
                      icon: CustomIconWidget(
                        iconName: 'zoom_out',
                        color: AppTheme.lightTheme.colorScheme.primary,
                        size: 6.w,
                      ),
                      tooltip: 'Zoom Out',
                    ),
                    IconButton(
                      onPressed: _resetView,
                      icon: CustomIconWidget(
                        iconName: 'center_focus_strong',
                        color: AppTheme.lightTheme.colorScheme.primary,
                        size: 6.w,
                      ),
                      tooltip: 'Reset View',
                    ),
                  ],
                ),
              ],
            ),
          ),

          // Radar map container
          Expanded(
            child: Container(
              margin: EdgeInsets.symmetric(horizontal: 4.w),
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                borderRadius: BorderRadius.circular(3.w),
                border: Border.all(
                  color: AppTheme.lightTheme.colorScheme.outline
                      .withValues(alpha: 0.2),
                  width: 1,
                ),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(3.w),
                child: GestureDetector(
                  onScaleStart: (details) {
                    // Handle scale start
                  },
                  onScaleUpdate: (details) {
                    setState(() {
                      _zoomLevel = (_zoomLevel * details.scale).clamp(0.5, 3.0);
                      _panOffset += details.focalPointDelta;
                    });
                  },
                  onPanUpdate: (details) {
                    setState(() {
                      _panOffset += details.delta;
                    });
                  },
                  child: Stack(
                    children: [
                      // Base map
                      Transform(
                        transform: Matrix4.identity()
                          ..translate(_panOffset.dx, _panOffset.dy)
                          ..scale(_zoomLevel),
                        child: Container(
                          width: double.infinity,
                          height: double.infinity,
                          child: CustomImageWidget(
                            imageUrl: widget.radarData['mapImage'] as String,
                            width: double.infinity,
                            height: double.infinity,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),

                      // Precipitation overlay
                      Transform(
                        transform: Matrix4.identity()
                          ..translate(_panOffset.dx, _panOffset.dy)
                          ..scale(_zoomLevel),
                        child: Container(
                          width: double.infinity,
                          height: double.infinity,
                          child: CustomPaint(
                            painter: PrecipitationOverlayPainter(
                              precipitationData:
                                  widget.radarData['precipitationData']
                                      as List<Map<String, dynamic>>,
                            ),
                          ),
                        ),
                      ),

                      // Location marker
                      Positioned(
                        left: 50.w - 3.w + _panOffset.dx,
                        top: 20.h - 3.w + _panOffset.dy,
                        child: Transform.scale(
                          scale: _zoomLevel,
                          child: Container(
                            width: 6.w,
                            height: 6.w,
                            decoration: BoxDecoration(
                              color: AppTheme.errorLight,
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: Colors.white,
                                width: 2,
                              ),
                            ),
                            child: Center(
                              child: CustomIconWidget(
                                iconName: 'my_location',
                                color: Colors.white,
                                size: 3.w,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          // Legend
          Container(
            margin: EdgeInsets.all(4.w),
            padding: EdgeInsets.all(3.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.surface
                  .withValues(alpha: 0.9),
              borderRadius: BorderRadius.circular(2.w),
              border: Border.all(
                color: AppTheme.lightTheme.colorScheme.outline
                    .withValues(alpha: 0.2),
                width: 1,
              ),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildLegendItem('Light', Color(0xFF87CEEB)),
                _buildLegendItem('Moderate', Color(0xFF4169E1)),
                _buildLegendItem('Heavy', Color(0xFF8B0000)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color) {
    return Row(
      children: [
        Container(
          width: 4.w,
          height: 4.w,
          decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(1.w),
          ),
        ),
        SizedBox(width: 2.w),
        Text(
          label,
          style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
            fontWeight: FontWeight.w500,
          ),
        ),
      ],
    );
  }

  void _zoomIn() {
    setState(() {
      _zoomLevel = (_zoomLevel * 1.2).clamp(0.5, 3.0);
    });
  }

  void _zoomOut() {
    setState(() {
      _zoomLevel = (_zoomLevel / 1.2).clamp(0.5, 3.0);
    });
  }

  void _resetView() {
    setState(() {
      _zoomLevel = 1.0;
      _panOffset = Offset.zero;
    });
  }
}

class PrecipitationOverlayPainter extends CustomPainter {
  final List<Map<String, dynamic>> precipitationData;

  PrecipitationOverlayPainter({required this.precipitationData});

  @override
  void paint(Canvas canvas, Size size) {
    for (final data in precipitationData) {
      final intensity = data['intensity'] as double;
      final x = (data['x'] as double) * size.width;
      final y = (data['y'] as double) * size.height;
      final radius = data['radius'] as double;

      final paint = Paint()
        ..color = _getIntensityColor(intensity)
        ..style = PaintingStyle.fill;

      canvas.drawCircle(Offset(x, y), radius, paint);
    }
  }

  Color _getIntensityColor(double intensity) {
    if (intensity < 0.3) {
      return Color(0xFF87CEEB).withValues(alpha: 0.6);
    } else if (intensity < 0.7) {
      return Color(0xFF4169E1).withValues(alpha: 0.7);
    } else {
      return Color(0xFF8B0000).withValues(alpha: 0.8);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => true;
}
