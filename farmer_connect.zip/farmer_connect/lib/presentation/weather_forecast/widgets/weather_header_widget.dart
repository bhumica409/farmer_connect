import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class WeatherHeaderWidget extends StatelessWidget {
  final Map<String, dynamic> currentWeather;
  final String locationName;

  const WeatherHeaderWidget({
    super.key,
    required this.currentWeather,
    required this.locationName,
  });

  @override
  Widget build(BuildContext context) {
    final temperature = currentWeather['temperature'] as int;
    final condition = currentWeather['condition'] as String;
    final farmingSuitability = currentWeather['farmingSuitability'] as String;
    final iconName = currentWeather['icon'] as String;

    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            AppTheme.lightTheme.colorScheme.primary,
            AppTheme.lightTheme.colorScheme.primary.withValues(alpha: 0.8),
          ],
        ),
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(6.w),
          bottomRight: Radius.circular(6.w),
        ),
      ),
      child: SafeArea(
        child: Column(
          children: [
            // Location and settings
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'location_on',
                        color: AppTheme.lightTheme.colorScheme.onPrimary,
                        size: 5.w,
                      ),
                      SizedBox(width: 2.w),
                      Expanded(
                        child: Text(
                          locationName,
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            color: AppTheme.lightTheme.colorScheme.onPrimary,
                            fontWeight: FontWeight.w500,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        // Show location selector
                      },
                      icon: CustomIconWidget(
                        iconName: 'edit_location',
                        color: AppTheme.lightTheme.colorScheme.onPrimary,
                        size: 6.w,
                      ),
                      tooltip: 'Change Location',
                    ),
                    IconButton(
                      onPressed: () {
                        // Show settings
                      },
                      icon: CustomIconWidget(
                        iconName: 'settings',
                        color: AppTheme.lightTheme.colorScheme.onPrimary,
                        size: 6.w,
                      ),
                      tooltip: 'Weather Settings',
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(height: 3.h),

            // Main weather display
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                // Temperature and condition
                Expanded(
                  flex: 2,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${temperature}°C',
                        style: AppTheme.lightTheme.textTheme.displayLarge
                            ?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.onPrimary,
                          fontWeight: FontWeight.w300,
                          fontSize: 16.sp,
                        ),
                      ),
                      SizedBox(height: 1.h),
                      Text(
                        condition,
                        style:
                            AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                          color: AppTheme.lightTheme.colorScheme.onPrimary
                              .withValues(alpha: 0.9),
                          fontWeight: FontWeight.w400,
                        ),
                      ),
                    ],
                  ),
                ),

                // Weather icon
                Expanded(
                  flex: 1,
                  child: Center(
                    child: CustomIconWidget(
                      iconName: iconName,
                      color: AppTheme.lightTheme.colorScheme.onPrimary,
                      size: 20.w,
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 3.h),

            // Farming suitability indicator
            Container(
              width: double.infinity,
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              decoration: BoxDecoration(
                color: _getSuitabilityColor(farmingSuitability)
                    .withValues(alpha: 0.2),
                borderRadius: BorderRadius.circular(3.w),
                border: Border.all(
                  color: _getSuitabilityColor(farmingSuitability),
                  width: 1,
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  CustomIconWidget(
                    iconName: _getSuitabilityIcon(farmingSuitability),
                    color: _getSuitabilityColor(farmingSuitability),
                    size: 5.w,
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Field Work: $farmingSuitability',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      color: _getSuitabilityColor(farmingSuitability),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Color _getSuitabilityColor(String suitability) {
    switch (suitability.toLowerCase()) {
      case 'good':
        return AppTheme.successLight;
      case 'moderate':
        return AppTheme.warningLight;
      case 'poor':
        return AppTheme.errorLight;
      default:
        return AppTheme.lightTheme.colorScheme.onPrimary;
    }
  }

  String _getSuitabilityIcon(String suitability) {
    switch (suitability.toLowerCase()) {
      case 'good':
        return 'check_circle';
      case 'moderate':
        return 'warning';
      case 'poor':
        return 'cancel';
      default:
        return 'help';
    }
  }
}
