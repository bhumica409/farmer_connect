import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class HourlyForecastWidget extends StatelessWidget {
  final List<Map<String, dynamic>> hourlyData;

  const HourlyForecastWidget({
    super.key,
    required this.hourlyData,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 20.h,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Text(
              'Next 24 Hours',
              style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          Expanded(
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: EdgeInsets.symmetric(horizontal: 2.w),
              itemCount: hourlyData.length,
              itemBuilder: (context, index) {
                final hour = hourlyData[index];
                return _buildHourlyCard(hour);
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHourlyCard(Map<String, dynamic> hour) {
    final time = hour['time'] as String;
    final temperature = hour['temperature'] as int;
    final precipitation = hour['precipitation'] as int;
    final windSpeed = hour['windSpeed'] as int;
    final icon = hour['icon'] as String;

    return Container(
      width: 20.w,
      margin: EdgeInsets.symmetric(horizontal: 1.w),
      padding: EdgeInsets.all(2.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.circular(3.w),
        border: Border.all(
          color: AppTheme.lightTheme.colorScheme.outline.withValues(alpha: 0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color:
                AppTheme.lightTheme.colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 4,
            offset: Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Time
          Text(
            time,
            style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
              fontWeight: FontWeight.w500,
            ),
          ),

          // Weather icon
          CustomIconWidget(
            iconName: icon,
            color: AppTheme.lightTheme.colorScheme.primary,
            size: 6.w,
          ),

          // Temperature
          Text(
            '${temperature}°',
            style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),

          // Precipitation
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: 'water_drop',
                color: AppTheme.lightTheme.colorScheme.primary,
                size: 3.w,
              ),
              SizedBox(width: 1.w),
              Text(
                '${precipitation}%',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  fontSize: 8.sp,
                ),
              ),
            ],
          ),

          // Wind speed
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CustomIconWidget(
                iconName: 'air',
                color: AppTheme.lightTheme.colorScheme.secondary,
                size: 3.w,
              ),
              SizedBox(width: 1.w),
              Text(
                '${windSpeed}km/h',
                style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                  fontSize: 8.sp,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
