import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/hourly_forecast_widget.dart';
import './widgets/precipitation_radar_widget.dart';
import './widgets/weather_alerts_widget.dart';
import './widgets/weather_details_sheet.dart';
import './widgets/weather_header_widget.dart';
import './widgets/weekly_forecast_widget.dart';

class WeatherForecast extends StatefulWidget {
  const WeatherForecast({super.key});

  @override
  State<WeatherForecast> createState() => _WeatherForecastState();
}

class _WeatherForecastState extends State<WeatherForecast>
    with TickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = false;
  String _selectedLocation = 'Hyderabad, Telangana';

  // Mock weather data
  final Map<String, dynamic> _currentWeather = {
    'temperature': 28,
    'condition': 'Partly Cloudy',
    'farmingSuitability': 'Good',
    'icon': 'partly_cloudy_day',
    'lastUpdated': '2025-08-24 12:07:48',
  };

  final List<Map<String, dynamic>> _hourlyForecast = [
    {
      'time': '1 PM',
      'temperature': 29,
      'precipitation': 10,
      'windSpeed': 12,
      'icon': 'wb_sunny',
    },
    {
      'time': '2 PM',
      'temperature': 31,
      'precipitation': 5,
      'windSpeed': 15,
      'icon': 'wb_sunny',
    },
    {
      'time': '3 PM',
      'temperature': 32,
      'precipitation': 15,
      'windSpeed': 18,
      'icon': 'partly_cloudy_day',
    },
    {
      'time': '4 PM',
      'temperature': 30,
      'precipitation': 25,
      'windSpeed': 20,
      'icon': 'cloud',
    },
    {
      'time': '5 PM',
      'temperature': 28,
      'precipitation': 40,
      'windSpeed': 22,
      'icon': 'grain',
    },
    {
      'time': '6 PM',
      'temperature': 26,
      'precipitation': 60,
      'windSpeed': 25,
      'icon': 'grain',
    },
  ];

  final List<Map<String, dynamic>> _weeklyForecast = [
    {
      'day': 'Today',
      'date': '24 Aug',
      'highTemp': 32,
      'lowTemp': 24,
      'rainfall': 5,
      'icon': 'partly_cloudy_day',
      'recommendation': 'Good day for field work and spraying activities',
    },
    {
      'day': 'Tomorrow',
      'date': '25 Aug',
      'highTemp': 30,
      'lowTemp': 22,
      'rainfall': 15,
      'icon': 'cloud',
      'recommendation': 'Light rain expected, avoid harvesting',
    },
    {
      'day': 'Monday',
      'date': '26 Aug',
      'highTemp': 28,
      'lowTemp': 20,
      'rainfall': 25,
      'icon': 'grain',
      'recommendation': 'Heavy rain likely, postpone outdoor activities',
    },
    {
      'day': 'Tuesday',
      'date': '27 Aug',
      'highTemp': 29,
      'lowTemp': 21,
      'rainfall': 10,
      'icon': 'partly_cloudy_day',
      'recommendation': 'Ideal conditions for planting and irrigation',
    },
    {
      'day': 'Wednesday',
      'date': '28 Aug',
      'highTemp': 31,
      'lowTemp': 23,
      'rainfall': 0,
      'icon': 'wb_sunny',
      'recommendation': 'Perfect weather for harvesting activities',
    },
    {
      'day': 'Thursday',
      'date': '29 Aug',
      'highTemp': 33,
      'lowTemp': 25,
      'rainfall': 0,
      'icon': 'wb_sunny',
      'recommendation': 'Hot and dry, ensure adequate irrigation',
    },
    {
      'day': 'Friday',
      'date': '30 Aug',
      'highTemp': 32,
      'lowTemp': 24,
      'rainfall': 5,
      'icon': 'partly_cloudy_day',
      'recommendation': 'Good conditions for general farm maintenance',
    },
  ];

  final List<Map<String, dynamic>> _weatherAlerts = [
    {
      'type': 'Heavy Rain',
      'title': 'Heavy Rainfall Warning',
      'message':
          'Heavy rainfall expected on Monday. Avoid harvesting and outdoor activities. Ensure proper drainage in fields.',
      'severity': 'High',
      'validUntil': '26 Aug, 11:59 PM',
    },
    {
      'type': 'Temperature',
      'title': 'High Temperature Alert',
      'message':
          'Temperatures may reach 35°C this week. Increase irrigation frequency and provide shade for livestock.',
      'severity': 'Medium',
      'validUntil': '30 Aug, 6:00 PM',
    },
  ];

  final Map<String, dynamic> _radarData = {
    'mapImage':
        'https://images.pexels.com/photos/87651/earth-blue-planet-globe-planet-87651.jpeg',
    'precipitationData': [
      {'x': 0.3, 'y': 0.4, 'radius': 20.0, 'intensity': 0.6},
      {'x': 0.6, 'y': 0.3, 'radius': 15.0, 'intensity': 0.8},
      {'x': 0.4, 'y': 0.7, 'radius': 25.0, 'intensity': 0.4},
    ],
  };

  final Map<String, dynamic> _detailedWeather = {
    'humidity': 68,
    'uvIndex': 7,
    'soilTemp': 25,
    'windDirection': 'SW',
    'pressure': 1013,
    'visibility': 10,
    'recommendations': [
      'Morning hours (6-10 AM) are ideal for spraying pesticides',
      'Soil moisture is adequate for planting new crops',
      'UV levels are high - protect workers with proper clothing',
      'Wind conditions are favorable for drone operations',
    ],
  };

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadWeatherData();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadWeatherData() async {
    setState(() => _isLoading = true);

    // Simulate API call
    await Future.delayed(Duration(seconds: 1));

    setState(() => _isLoading = false);
  }

  Future<void> _refreshWeatherData() async {
    await _loadWeatherData();
  }

  void _showLocationSelector() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => _buildLocationSelector(),
    );
  }

  void _showWeatherDetails() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => WeatherDetailsSheet(
        detailedWeather: _detailedWeather,
      ),
    );
  }

  void _showNotificationSettings() {
    Navigator.pushNamed(context, '/user-profile-settings');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      body: _isLoading
          ? _buildLoadingState()
          : RefreshIndicator(
              onRefresh: _refreshWeatherData,
              child: Column(
                children: [
                  // Weather header
                  WeatherHeaderWidget(
                    currentWeather: _currentWeather,
                    locationName: _selectedLocation,
                  ),

                  // Tab bar
                  Container(
                    color: AppTheme.lightTheme.colorScheme.surface,
                    child: TabBar(
                      controller: _tabController,
                      indicatorColor: AppTheme.lightTheme.colorScheme.primary,
                      labelColor: AppTheme.lightTheme.colorScheme.primary,
                      unselectedLabelColor: AppTheme
                          .lightTheme.colorScheme.onSurface
                          .withValues(alpha: 0.6),
                      tabs: [
                        Tab(text: 'Hourly'),
                        Tab(text: 'Weekly'),
                        Tab(text: 'Radar'),
                      ],
                    ),
                  ),

                  // Tab content
                  Expanded(
                    child: TabBarView(
                      controller: _tabController,
                      children: [
                        _buildHourlyTab(),
                        _buildWeeklyTab(),
                        _buildRadarTab(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: _showWeatherDetails,
        tooltip: 'Weather Details',
        child: CustomIconWidget(
          iconName: 'info',
          color: AppTheme.lightTheme.colorScheme.onTertiary,
          size: 6.w,
        ),
      ),
    );
  }

  Widget _buildLoadingState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircularProgressIndicator(
            color: AppTheme.lightTheme.colorScheme.primary,
          ),
          SizedBox(height: 2.h),
          Text(
            'Loading weather data...',
            style: AppTheme.lightTheme.textTheme.bodyLarge,
          ),
        ],
      ),
    );
  }

  Widget _buildHourlyTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(height: 2.h),
          HourlyForecastWidget(hourlyData: _hourlyForecast),
          SizedBox(height: 2.h),
          WeatherAlertsWidget(alerts: _weatherAlerts),
          SizedBox(height: 10.h), // Space for FAB
        ],
      ),
    );
  }

  Widget _buildWeeklyTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(height: 2.h),
          WeeklyForecastWidget(weeklyData: _weeklyForecast),
          SizedBox(height: 10.h), // Space for FAB
        ],
      ),
    );
  }

  Widget _buildRadarTab() {
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(height: 2.h),
          PrecipitationRadarWidget(radarData: _radarData),
          SizedBox(height: 2.h),
          WeatherAlertsWidget(alerts: _weatherAlerts),
          SizedBox(height: 10.h), // Space for FAB
        ],
      ),
    );
  }

  Widget _buildLocationSelector() {
    final locations = [
      'Hyderabad, Telangana',
      'Bangalore, Karnataka',
      'Chennai, Tamil Nadu',
      'Mumbai, Maharashtra',
      'Delhi, NCR',
      'Pune, Maharashtra',
    ];

    return Container(
      padding: EdgeInsets.all(4.w),
      decoration: BoxDecoration(
        color: AppTheme.lightTheme.colorScheme.surface,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(6.w),
          topRight: Radius.circular(6.w),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Container(
            width: 12.w,
            height: 1.h,
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.outline
                  .withValues(alpha: 0.3),
              borderRadius: BorderRadius.circular(0.5.h),
            ),
          ),

          SizedBox(height: 3.h),

          Text(
            'Select Location',
            style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
              fontWeight: FontWeight.w600,
            ),
          ),

          SizedBox(height: 3.h),

          // Location list
          ListView.builder(
            shrinkWrap: true,
            itemCount: locations.length,
            itemBuilder: (context, index) {
              final location = locations[index];
              final isSelected = location == _selectedLocation;

              return ListTile(
                leading: CustomIconWidget(
                  iconName: 'location_on',
                  color: isSelected
                      ? AppTheme.lightTheme.colorScheme.primary
                      : AppTheme.lightTheme.colorScheme.onSurface
                          .withValues(alpha: 0.6),
                  size: 6.w,
                ),
                title: Text(
                  location,
                  style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                    color: isSelected
                        ? AppTheme.lightTheme.colorScheme.primary
                        : AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
                trailing: isSelected
                    ? CustomIconWidget(
                        iconName: 'check_circle',
                        color: AppTheme.lightTheme.colorScheme.primary,
                        size: 6.w,
                      )
                    : null,
                onTap: () {
                  setState(() {
                    _selectedLocation = location;
                  });
                  Navigator.pop(context);
                  _loadWeatherData();
                },
              );
            },
          ),

          SizedBox(height: 2.h),
        ],
      ),
    );
  }
}
