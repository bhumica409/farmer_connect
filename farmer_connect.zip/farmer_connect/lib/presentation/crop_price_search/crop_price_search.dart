import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/crop_category_chips.dart';
import './widgets/crop_price_card.dart';
import './widgets/crop_search_bar.dart';
import './widgets/empty_search_state.dart';
import './widgets/filter_modal.dart';
import './widgets/recent_searches.dart';

class CropPriceSearch extends StatefulWidget {
  const CropPriceSearch({super.key});

  @override
  State<CropPriceSearch> createState() => _CropPriceSearchState();
}

class _CropPriceSearchState extends State<CropPriceSearch> {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  String _selectedCategory = 'All';
  List<String> _recentSearches = ['Wheat', 'Rice', 'Tomato', 'Onion'];
  List<Map<String, dynamic>> _filteredCrops = [];
  bool _isLoading = false;
  bool _isSearching = false;
  double _minPrice = 0;
  double _maxPrice = 10000;
  String _selectedLocation = '';

  final List<String> _categories = [
    'All',
    'Cereals',
    'Vegetables',
    'Fruits',
    'Spices',
    'Pulses',
  ];

  final List<String> _availableLocations = [
    'Delhi',
    'Mumbai',
    'Bangalore',
    'Chennai',
    'Kolkata',
    'Hyderabad',
    'Pune',
    'Ahmedabad',
  ];

  final List<String> _suggestedCrops = [
    'Wheat',
    'Rice',
    'Tomato',
    'Onion',
    'Potato',
    'Carrot',
    'Apple',
    'Banana',
    'Turmeric',
    'Chili',
  ];

  // Mock crop data
  final List<Map<String, dynamic>> _allCrops = [
    {
      'id': 1,
      'name': 'Wheat',
      'localName': 'गेहूं',
      'price': 2150.0,
      'change': 2.5,
      'location': 'Delhi Mandi',
      'category': 'Cereals',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/4110256/pexels-photo-4110256.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 2,
      'name': 'Rice',
      'localName': 'चावल',
      'price': 3200.0,
      'change': -1.2,
      'location': 'Mumbai Market',
      'category': 'Cereals',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/1393382/pexels-photo-1393382.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 3,
      'name': 'Tomato',
      'localName': 'टमाटर',
      'price': 4500.0,
      'change': 8.7,
      'location': 'Bangalore APMC',
      'category': 'Vegetables',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/533280/pexels-photo-533280.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 4,
      'name': 'Onion',
      'localName': 'प्याज',
      'price': 2800.0,
      'change': -3.4,
      'location': 'Chennai Market',
      'category': 'Vegetables',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/144248/onions-food-vegetables-healthy-144248.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 5,
      'name': 'Apple',
      'localName': 'सेब',
      'price': 8500.0,
      'change': 1.8,
      'location': 'Delhi Fruit Market',
      'category': 'Fruits',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/102104/pexels-photo-102104.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 6,
      'name': 'Banana',
      'localName': 'केला',
      'price': 3500.0,
      'change': 4.2,
      'location': 'Hyderabad Market',
      'category': 'Fruits',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/2872755/pexels-photo-2872755.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 7,
      'name': 'Turmeric',
      'localName': 'हल्दी',
      'price': 12000.0,
      'change': 6.5,
      'location': 'Pune Spice Market',
      'category': 'Spices',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/4198015/pexels-photo-4198015.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 8,
      'name': 'Chili',
      'localName': 'मिर्च',
      'price': 15000.0,
      'change': -2.1,
      'location': 'Ahmedabad Market',
      'category': 'Spices',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/1437267/pexels-photo-1437267.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 9,
      'name': 'Lentils',
      'localName': 'दाल',
      'price': 7500.0,
      'change': 3.2,
      'location': 'Kolkata Market',
      'category': 'Pulses',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/4198019/pexels-photo-4198019.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
    {
      'id': 10,
      'name': 'Chickpeas',
      'localName': 'चना',
      'price': 6800.0,
      'change': 1.5,
      'location': 'Delhi Grain Market',
      'category': 'Pulses',
      'unit': 'quintal',
      'image':
          'https://images.pexels.com/photos/4198017/pexels-photo-4198017.jpeg?auto=compress&cs=tinysrgb&w=400',
    },
  ];

  @override
  void initState() {
    super.initState();
    _filteredCrops = List.from(_allCrops);
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  void _onSearchChanged() {
    final query = _searchController.text.toLowerCase().trim();
    setState(() {
      _isSearching = query.isNotEmpty;
      _filterCrops();
    });
  }

  void _filterCrops() {
    final query = _searchController.text.toLowerCase().trim();

    setState(() {
      _filteredCrops = _allCrops.where((crop) {
        final matchesSearch = query.isEmpty ||
            (crop['name'] as String).toLowerCase().contains(query) ||
            (crop['localName'] as String).toLowerCase().contains(query);

        final matchesCategory =
            _selectedCategory == 'All' || crop['category'] == _selectedCategory;

        final price = crop['price'] as double;
        final matchesPrice = price >= _minPrice && price <= _maxPrice;

        final matchesLocation = _selectedLocation.isEmpty ||
            (crop['location'] as String).contains(_selectedLocation);

        return matchesSearch &&
            matchesCategory &&
            matchesPrice &&
            matchesLocation;
      }).toList();
    });
  }

  void _onCategorySelected(String category) {
    setState(() {
      _selectedCategory = category;
      _filterCrops();
    });
  }

  void _onRecentSearchTap(String search) {
    _searchController.text = search;
    _onSearchChanged();
  }

  void _onSuggestionTap(String suggestion) {
    _searchController.text = suggestion;
    _addToRecentSearches(suggestion);
    _onSearchChanged();
  }

  void _addToRecentSearches(String search) {
    if (search.trim().isEmpty) return;

    setState(() {
      _recentSearches.remove(search);
      _recentSearches.insert(0, search);
      if (_recentSearches.length > 10) {
        _recentSearches = _recentSearches.take(10).toList();
      }
    });
  }

  void _clearRecentSearches() {
    setState(() {
      _recentSearches.clear();
    });
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      _isSearching = false;
      _filterCrops();
    });
  }

  void _onVoiceSearch() {
    // Voice search implementation would go here
    // For now, show a placeholder message
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Voice search feature coming soon!'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      ),
    );
  }

  void _showFilterModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => FilterModal(
        minPrice: _minPrice,
        maxPrice: _maxPrice,
        selectedLocation: _selectedLocation,
        availableLocations: _availableLocations,
        onApplyFilter: (min, max, location) {
          setState(() {
            _minPrice = min;
            _maxPrice = max;
            _selectedLocation = location;
            _filterCrops();
          });
        },
      ),
    );
  }

  Future<void> _refreshPrices() async {
    setState(() {
      _isLoading = true;
    });

    // Simulate API call
    await Future.delayed(Duration(seconds: 2));

    setState(() {
      _isLoading = false;
      // In real app, this would update prices from API
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Prices updated successfully!'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      ),
    );
  }

  void _onCropTap(Map<String, dynamic> crop) {
    // Navigate to crop detail screen
    // Navigator.pushNamed(context, '/crop-detail', arguments: crop);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening ${crop['name']} details...'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
      ),
    );
  }

  void _onAddToWatchlist(Map<String, dynamic> crop) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('${crop['name']} added to watchlist'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        action: SnackBarAction(
          label: 'View',
          textColor: AppTheme.lightTheme.colorScheme.onPrimary,
          onPressed: () {
            // Navigate to watchlist
          },
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text('Crop Prices'),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        foregroundColor: AppTheme.lightTheme.colorScheme.onPrimary,
        elevation: 0,
        actions: [
          IconButton(
            onPressed: _showFilterModal,
            icon: CustomIconWidget(
              iconName: 'filter_list',
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              size: 24,
            ),
            tooltip: 'Filter',
          ),
          IconButton(
            onPressed: () =>
                Navigator.pushNamed(context, '/user-profile-settings'),
            icon: CustomIconWidget(
              iconName: 'account_circle',
              color: AppTheme.lightTheme.colorScheme.onPrimary,
              size: 24,
            ),
            tooltip: 'Profile',
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          CropSearchBar(
            controller: _searchController,
            onChanged: (value) => _onSearchChanged(),
            onVoiceSearch: _onVoiceSearch,
            onClear: _clearSearch,
            hintText: 'Search crops, prices...',
          ),

          // Category Chips
          CropCategoryChips(
            categories: _categories,
            selectedCategory: _selectedCategory,
            onCategorySelected: _onCategorySelected,
          ),

          // Content Area
          Expanded(
            child: _buildContent(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () =>
            Navigator.pushNamed(context, '/farmer-discussion-forum'),
        backgroundColor: AppTheme.lightTheme.colorScheme.tertiary,
        foregroundColor: AppTheme.lightTheme.colorScheme.onTertiary,
        child: CustomIconWidget(
          iconName: 'forum',
          color: AppTheme.lightTheme.colorScheme.onTertiary,
          size: 24,
        ),
        tooltip: 'Discussion Forum',
      ),
    );
  }

  Widget _buildContent() {
    if (!_isSearching && _searchController.text.isEmpty) {
      return SingleChildScrollView(
        child: Column(
          children: [
            // Recent Searches
            RecentSearches(
              recentSearches: _recentSearches,
              onSearchTap: _onRecentSearchTap,
              onClearAll: _clearRecentSearches,
            ),

            // Popular Crops Section
            Container(
              margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 2.h),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Popular Crops',
                    style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  SizedBox(height: 2.h),
                  ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: _allCrops.take(5).length,
                    itemBuilder: (context, index) {
                      final crop = _allCrops[index];
                      return CropPriceCard(
                        cropData: crop,
                        onTap: () => _onCropTap(crop),
                        onAddToWatchlist: () => _onAddToWatchlist(crop),
                      );
                    },
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    if (_filteredCrops.isEmpty) {
      return EmptySearchState(
        searchQuery: _searchController.text,
        suggestedCrops: _suggestedCrops,
        onSuggestionTap: _onSuggestionTap,
        onBrowseCategories: () {
          setState(() {
            _selectedCategory = 'Vegetables';
            _filterCrops();
          });
        },
      );
    }

    return RefreshIndicator(
      onRefresh: _refreshPrices,
      color: AppTheme.lightTheme.colorScheme.primary,
      child: ListView.builder(
        controller: _scrollController,
        physics: AlwaysScrollableScrollPhysics(),
        itemCount: _filteredCrops.length + 1,
        itemBuilder: (context, index) {
          if (index == 0) {
            return Container(
              padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
              child: Text(
                '${_filteredCrops.length} crops found',
                style: AppTheme.lightTheme.textTheme.bodyMedium?.copyWith(
                  color: AppTheme.lightTheme.colorScheme.onSurface
                      .withValues(alpha: 0.7),
                ),
              ),
            );
          }

          final crop = _filteredCrops[index - 1];
          return CropPriceCard(
            cropData: crop,
            onTap: () => _onCropTap(crop),
            onAddToWatchlist: () => _onAddToWatchlist(crop),
          );
        },
      ),
    );
  }
}
