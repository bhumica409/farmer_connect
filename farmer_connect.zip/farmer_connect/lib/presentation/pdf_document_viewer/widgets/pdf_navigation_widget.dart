import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PdfNavigationWidget extends StatelessWidget {
  final int currentPage;
  final int totalPages;
  final bool isVisible;
  final ValueChanged<int>? onPageChanged;
  final VoidCallback? onThumbnailPressed;
  final bool isNightMode;
  final VoidCallback? onNightModeToggle;

  const PdfNavigationWidget({
    super.key,
    required this.currentPage,
    required this.totalPages,
    this.isVisible = true,
    this.onPageChanged,
    this.onThumbnailPressed,
    this.isNightMode = false,
    this.onNightModeToggle,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedOpacity(
      opacity: isVisible ? 1.0 : 0.0,
      duration: Duration(milliseconds: 300),
      child: Container(
        height: 12.h,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.bottomCenter,
            end: Alignment.topCenter,
            colors: [
              AppTheme.lightTheme.colorScheme.surface,
              AppTheme.lightTheme.colorScheme.surface.withValues(alpha: 0.9),
            ],
          ),
          boxShadow: [
            BoxShadow(
              color:
                  AppTheme.lightTheme.colorScheme.shadow.withValues(alpha: 0.1),
              blurRadius: 4,
              offset: Offset(0, -2),
            ),
          ],
        ),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Column(
              children: [
                // Page slider
                Row(
                  children: [
                    // Previous page button
                    GestureDetector(
                      onTap: currentPage > 1
                          ? () => onPageChanged?.call(currentPage - 1)
                          : null,
                      child: Container(
                        padding: EdgeInsets.all(2.w),
                        decoration: BoxDecoration(
                          color: currentPage > 1
                              ? AppTheme.lightTheme.colorScheme.primary
                                  .withValues(alpha: 0.1)
                              : AppTheme.lightTheme.colorScheme.surface
                                  .withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: CustomIconWidget(
                          iconName: 'chevron_left',
                          color: currentPage > 1
                              ? AppTheme.lightTheme.colorScheme.primary
                              : AppTheme.lightTheme.colorScheme.onSurface
                                  .withValues(alpha: 0.3),
                          size: 20,
                        ),
                      ),
                    ),
                    SizedBox(width: 3.w),

                    // Page slider
                    Expanded(
                      child: SliderTheme(
                        data: SliderTheme.of(context).copyWith(
                          activeTrackColor:
                              AppTheme.lightTheme.colorScheme.primary,
                          inactiveTrackColor: AppTheme
                              .lightTheme.colorScheme.outline
                              .withValues(alpha: 0.3),
                          thumbColor: AppTheme.lightTheme.colorScheme.primary,
                          overlayColor: AppTheme.lightTheme.colorScheme.primary
                              .withValues(alpha: 0.2),
                          trackHeight: 4,
                          thumbShape:
                              RoundSliderThumbShape(enabledThumbRadius: 8),
                        ),
                        child: Slider(
                          value: currentPage.toDouble(),
                          min: 1,
                          max: totalPages.toDouble(),
                          divisions: totalPages > 1 ? totalPages - 1 : 1,
                          onChanged: (value) =>
                              onPageChanged?.call(value.round()),
                        ),
                      ),
                    ),
                    SizedBox(width: 3.w),

                    // Next page button
                    GestureDetector(
                      onTap: currentPage < totalPages
                          ? () => onPageChanged?.call(currentPage + 1)
                          : null,
                      child: Container(
                        padding: EdgeInsets.all(2.w),
                        decoration: BoxDecoration(
                          color: currentPage < totalPages
                              ? AppTheme.lightTheme.colorScheme.primary
                                  .withValues(alpha: 0.1)
                              : AppTheme.lightTheme.colorScheme.surface
                                  .withValues(alpha: 0.5),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: CustomIconWidget(
                          iconName: 'chevron_right',
                          color: currentPage < totalPages
                              ? AppTheme.lightTheme.colorScheme.primary
                              : AppTheme.lightTheme.colorScheme.onSurface
                                  .withValues(alpha: 0.3),
                          size: 20,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 1.h),

                // Bottom controls
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Page info
                    Container(
                      padding:
                          EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
                      decoration: BoxDecoration(
                        color: AppTheme.lightTheme.colorScheme.surface
                            .withValues(alpha: 0.8),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: AppTheme.lightTheme.colorScheme.outline
                              .withValues(alpha: 0.2),
                          width: 1,
                        ),
                      ),
                      child: Text(
                        'Page $currentPage of $totalPages',
                        style:
                            AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                          fontWeight: FontWeight.w500,
                          color: AppTheme.lightTheme.colorScheme.onSurface,
                        ),
                      ),
                    ),

                    // Control buttons
                    Row(
                      children: [
                        // Thumbnail view button
                        GestureDetector(
                          onTap: onThumbnailPressed,
                          child: Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color: AppTheme.lightTheme.colorScheme.surface
                                  .withValues(alpha: 0.8),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: CustomIconWidget(
                              iconName: 'view_module',
                              color: AppTheme.lightTheme.colorScheme.onSurface,
                              size: 20,
                            ),
                          ),
                        ),
                        SizedBox(width: 2.w),

                        // Night mode toggle
                        GestureDetector(
                          onTap: onNightModeToggle,
                          child: Container(
                            padding: EdgeInsets.all(2.w),
                            decoration: BoxDecoration(
                              color: isNightMode
                                  ? AppTheme.lightTheme.colorScheme.primary
                                      .withValues(alpha: 0.1)
                                  : AppTheme.lightTheme.colorScheme.surface
                                      .withValues(alpha: 0.8),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: CustomIconWidget(
                              iconName:
                                  isNightMode ? 'light_mode' : 'dark_mode',
                              color: isNightMode
                                  ? AppTheme.lightTheme.colorScheme.primary
                                  : AppTheme.lightTheme.colorScheme.onSurface,
                              size: 20,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
