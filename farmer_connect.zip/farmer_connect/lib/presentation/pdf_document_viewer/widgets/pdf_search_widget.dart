import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class PdfSearchWidget extends StatefulWidget {
  final bool isVisible;
  final ValueChanged<String>? onSearchChanged;
  final VoidCallback? onPreviousMatch;
  final VoidCallback? onNextMatch;
  final VoidCallback? onCloseSearch;
  final int currentMatch;
  final int totalMatches;

  const PdfSearchWidget({
    super.key,
    this.isVisible = false,
    this.onSearchChanged,
    this.onPreviousMatch,
    this.onNextMatch,
    this.onCloseSearch,
    this.currentMatch = 0,
    this.totalMatches = 0,
  });

  @override
  State<PdfSearchWidget> createState() => _PdfSearchWidgetState();
}

class _PdfSearchWidgetState extends State<PdfSearchWidget> {
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();

  @override
  void dispose() {
    _searchController.dispose();
    _searchFocusNode.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: Duration(milliseconds: 300),
      height: widget.isVisible ? 12.h : 0,
      child: widget.isVisible
          ? Container(
              decoration: BoxDecoration(
                color: AppTheme.lightTheme.colorScheme.surface,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.lightTheme.colorScheme.shadow
                        .withValues(alpha: 0.1),
                    blurRadius: 4,
                    offset: Offset(0, 2),
                  ),
                ],
              ),
              child: SafeArea(
                child: Padding(
                  padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
                  child: Row(
                    children: [
                      // Search input
                      Expanded(
                        child: Container(
                          height: 6.h,
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.surface,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppTheme.lightTheme.colorScheme.outline
                                  .withValues(alpha: 0.3),
                              width: 1,
                            ),
                          ),
                          child: TextField(
                            controller: _searchController,
                            focusNode: _searchFocusNode,
                            onChanged: widget.onSearchChanged,
                            style: AppTheme.lightTheme.textTheme.bodyMedium
                                ?.copyWith(
                              color: AppTheme.lightTheme.colorScheme.onSurface,
                            ),
                            decoration: InputDecoration(
                              hintText: 'Search in document...',
                              hintStyle: AppTheme
                                  .lightTheme.textTheme.bodyMedium
                                  ?.copyWith(
                                color: AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.6),
                              ),
                              prefixIcon: Padding(
                                padding: EdgeInsets.all(3.w),
                                child: CustomIconWidget(
                                  iconName: 'search',
                                  color: AppTheme
                                      .lightTheme.colorScheme.onSurface
                                      .withValues(alpha: 0.6),
                                  size: 20,
                                ),
                              ),
                              suffixIcon: _searchController.text.isNotEmpty
                                  ? GestureDetector(
                                      onTap: () {
                                        _searchController.clear();
                                        widget.onSearchChanged?.call('');
                                      },
                                      child: Padding(
                                        padding: EdgeInsets.all(3.w),
                                        child: CustomIconWidget(
                                          iconName: 'clear',
                                          color: AppTheme
                                              .lightTheme.colorScheme.onSurface
                                              .withValues(alpha: 0.6),
                                          size: 20,
                                        ),
                                      ),
                                    )
                                  : null,
                              border: InputBorder.none,
                              contentPadding: EdgeInsets.symmetric(
                                  horizontal: 4.w, vertical: 2.h),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 3.w),

                      // Search results info
                      if (widget.totalMatches > 0) ...[
                        Container(
                          padding: EdgeInsets.symmetric(
                              horizontal: 3.w, vertical: 1.h),
                          decoration: BoxDecoration(
                            color: AppTheme.lightTheme.colorScheme.primary
                                .withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: Text(
                            '${widget.currentMatch}/${widget.totalMatches}',
                            style: AppTheme.lightTheme.textTheme.bodySmall
                                ?.copyWith(
                              fontWeight: FontWeight.w500,
                              color: AppTheme.lightTheme.colorScheme.primary,
                            ),
                          ),
                        ),
                        SizedBox(width: 2.w),
                      ],

                      // Navigation buttons
                      Row(
                        children: [
                          // Previous match
                          GestureDetector(
                            onTap: widget.totalMatches > 0
                                ? widget.onPreviousMatch
                                : null,
                            child: Container(
                              padding: EdgeInsets.all(2.w),
                              decoration: BoxDecoration(
                                color: widget.totalMatches > 0
                                    ? AppTheme.lightTheme.colorScheme.surface
                                        .withValues(alpha: 0.8)
                                    : AppTheme.lightTheme.colorScheme.surface
                                        .withValues(alpha: 0.5),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: CustomIconWidget(
                                iconName: 'keyboard_arrow_up',
                                color: widget.totalMatches > 0
                                    ? AppTheme.lightTheme.colorScheme.onSurface
                                    : AppTheme.lightTheme.colorScheme.onSurface
                                        .withValues(alpha: 0.3),
                                size: 20,
                              ),
                            ),
                          ),
                          SizedBox(width: 1.w),

                          // Next match
                          GestureDetector(
                            onTap: widget.totalMatches > 0
                                ? widget.onNextMatch
                                : null,
                            child: Container(
                              padding: EdgeInsets.all(2.w),
                              decoration: BoxDecoration(
                                color: widget.totalMatches > 0
                                    ? AppTheme.lightTheme.colorScheme.surface
                                        .withValues(alpha: 0.8)
                                    : AppTheme.lightTheme.colorScheme.surface
                                        .withValues(alpha: 0.5),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: CustomIconWidget(
                                iconName: 'keyboard_arrow_down',
                                color: widget.totalMatches > 0
                                    ? AppTheme.lightTheme.colorScheme.onSurface
                                    : AppTheme.lightTheme.colorScheme.onSurface
                                        .withValues(alpha: 0.3),
                                size: 20,
                              ),
                            ),
                          ),
                          SizedBox(width: 2.w),

                          // Close search
                          GestureDetector(
                            onTap: widget.onCloseSearch,
                            child: Container(
                              padding: EdgeInsets.all(2.w),
                              decoration: BoxDecoration(
                                color: AppTheme.lightTheme.colorScheme.surface
                                    .withValues(alpha: 0.8),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: CustomIconWidget(
                                iconName: 'close',
                                color:
                                    AppTheme.lightTheme.colorScheme.onSurface,
                                size: 20,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            )
          : SizedBox.shrink(),
    );
  }
}
