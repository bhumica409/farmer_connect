import 'dart:convert';
import 'dart:io' if (dart.library.io) 'dart:io';

import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sizer/sizer.dart';
import 'package:universal_html/html.dart' as html;

import '../../core/app_export.dart';
import '../../theme/app_theme.dart';
import '../../widgets/custom_icon_widget.dart';
import './widgets/pdf_bookmark_widget.dart';
import './widgets/pdf_navigation_widget.dart';
import './widgets/pdf_search_widget.dart';
import './widgets/pdf_thumbnail_grid_widget.dart';
import './widgets/pdf_toolbar_widget.dart';
import 'widgets/pdf_bookmark_widget.dart';
import 'widgets/pdf_navigation_widget.dart';
import 'widgets/pdf_search_widget.dart';
import 'widgets/pdf_thumbnail_grid_widget.dart';
import 'widgets/pdf_toolbar_widget.dart';

class PdfDocumentViewer extends StatefulWidget {
  const PdfDocumentViewer({super.key});

  @override
  State<PdfDocumentViewer> createState() => _PdfDocumentViewerState();
}

class _PdfDocumentViewerState extends State<PdfDocumentViewer>
    with TickerProviderStateMixin {
  // UI State
  bool _isToolbarVisible = true;
  bool _isNavigationVisible = true;
  bool _isSearchVisible = false;
  bool _isThumbnailVisible = false;
  bool _isBookmarkVisible = false;
  bool _isNightMode = false;
  bool _isDownloaded = false;
  bool _isBookmarked = false;
  bool _isDownloading = false;

  // PDF State
  int _currentPage = 1;
  int _totalPages = 45; // Mock total pages for agricultural guide
  double _zoomLevel = 1.0;
  String _documentTitle = "Organic Farming Guide 2024";
  String _searchQuery = "";
  int _currentSearchMatch = 0;
  int _totalSearchMatches = 0;

  // Controllers
  late AnimationController _toolbarAnimationController;
  late AnimationController _zoomAnimationController;
  late Timer? _hideControlsTimer;

  // Mock data
  final List<BookmarkItem> _bookmarks = [
    BookmarkItem(
      pageNumber: 5,
      note: "Important soil preparation techniques",
      createdAt: DateTime.now().subtract(Duration(days: 2)),
    ),
    BookmarkItem(
      pageNumber: 12,
      note: "Organic pest control methods",
      createdAt: DateTime.now().subtract(Duration(days: 1)),
    ),
    BookmarkItem(
      pageNumber: 23,
      note: "Crop rotation schedule",
      createdAt: DateTime.now().subtract(Duration(hours: 3)),
    ),
  ];

  // Mock PDF content for demonstration
  final List<Map<String, dynamic>> _pdfPages = [
    {
      "pageNumber": 1,
      "title": "Introduction to Organic Farming",
      "content":
          "Organic farming is a method of crop and livestock production that involves much more than choosing not to use pesticides, fertilizers, genetically modified organisms, antibiotics and growth hormones.",
    },
    {
      "pageNumber": 2,
      "title": "Soil Health Management",
      "content":
          "Healthy soil is the foundation of organic farming. It provides nutrients, water, oxygen, and support to the roots of plants.",
    },
    {
      "pageNumber": 3,
      "title": "Crop Selection and Planning",
      "content":
          "Selecting the right crops for your region and planning their cultivation is crucial for successful organic farming.",
    },
  ];

  @override
  void initState() {
    super.initState();
    _initializeControllers();
    _loadDocumentProgress();
    _startHideControlsTimer();
  }

  @override
  void dispose() {
    _toolbarAnimationController.dispose();
    _zoomAnimationController.dispose();
    _hideControlsTimer?.cancel();
    super.dispose();
  }

  void _initializeControllers() {
    _toolbarAnimationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    _zoomAnimationController = AnimationController(
      duration: Duration(milliseconds: 200),
      vsync: this,
    );
  }

  void _loadDocumentProgress() {
    // Mock loading saved progress
    setState(() {
      _currentPage = 8; // Resume from last read page
      _isBookmarked = _bookmarks.any((b) => b.pageNumber == _currentPage);
    });
  }

  void _startHideControlsTimer() {
    _hideControlsTimer?.cancel();
    _hideControlsTimer = Timer(Duration(seconds: 3), () {
      if (mounted &&
          !_isSearchVisible &&
          !_isThumbnailVisible &&
          !_isBookmarkVisible) {
        setState(() {
          _isToolbarVisible = false;
          _isNavigationVisible = false;
        });
      }
    });
  }

  void _showControls() {
    setState(() {
      _isToolbarVisible = true;
      _isNavigationVisible = true;
    });
    _startHideControlsTimer();
  }

  void _toggleControls() {
    setState(() {
      _isToolbarVisible = !_isToolbarVisible;
      _isNavigationVisible = !_isNavigationVisible;
    });
    if (_isToolbarVisible) {
      _startHideControlsTimer();
    }
  }

  // File Operations
  Future<void> _downloadDocument() async {
    if (_isDownloading) return;

    setState(() {
      _isDownloading = true;
    });

    try {
      // Mock PDF content
      final pdfContent = _generateMockPdfContent();

      await _downloadFile(
          pdfContent, '${_documentTitle.replaceAll(' ', '_')}.pdf');

      setState(() {
        _isDownloaded = true;
        _isDownloading = false;
      });

      _showSuccessMessage('Document downloaded successfully');
    } catch (e) {
      setState(() {
        _isDownloading = false;
      });
      _showErrorMessage('Failed to download document');
    }
  }

  Future<void> _downloadFile(String content, String filename) async {
    try {
      if (kIsWeb) {
        final bytes = utf8.encode(content);
        final blob = html.Blob([bytes]);
        final url = html.Url.createObjectUrlFromBlob(blob);
        final anchor = html.AnchorElement(href: url)
          ..setAttribute("download", filename)
          ..click();
        html.Url.revokeObjectUrl(url);
      } else {
        final directory = await getApplicationDocumentsDirectory();
        final file = File('${directory.path}/$filename');
        await file.writeAsString(content);
      }
    } catch (e) {
      throw Exception('Download failed');
    }
  }

  String _generateMockPdfContent() {
    final buffer = StringBuffer();
    buffer.writeln('ORGANIC FARMING GUIDE 2024');
    buffer.writeln('=' * 50);
    buffer.writeln();

    for (final page in _pdfPages) {
      buffer.writeln('Page ${page["pageNumber"]}: ${page["title"]}');
      buffer.writeln('-' * 30);
      buffer.writeln(page["content"]);
      buffer.writeln();
    }

    return buffer.toString();
  }

  Future<void> _shareDocument() async {
    try {
      if (kIsWeb) {
        // Web sharing via clipboard
        await Clipboard.setData(ClipboardData(
            text: 'Check out this agricultural guide: $_documentTitle'));
        _showSuccessMessage('Link copied to clipboard');
      } else {
        // Mobile sharing would use share_plus package
        _showSuccessMessage('Sharing options opened');
      }
    } catch (e) {
      _showErrorMessage('Failed to share document');
    }
  }

  // Bookmark Management
  void _toggleBookmark() {
    setState(() {
      if (_isBookmarked) {
        _bookmarks.removeWhere((b) => b.pageNumber == _currentPage);
        _isBookmarked = false;
        _showSuccessMessage('Bookmark removed');
      } else {
        _bookmarks.add(BookmarkItem(
          pageNumber: _currentPage,
          note: "Bookmarked on ${DateTime.now().toString().split(' ')[0]}",
          createdAt: DateTime.now(),
        ));
        _isBookmarked = true;
        _showSuccessMessage('Page bookmarked');
      }
    });
  }

  void _deleteBookmark(BookmarkItem bookmark) {
    setState(() {
      _bookmarks.remove(bookmark);
      if (bookmark.pageNumber == _currentPage) {
        _isBookmarked = false;
      }
    });
    _showSuccessMessage('Bookmark deleted');
  }

  // Search Functionality
  void _performSearch(String query) {
    setState(() {
      _searchQuery = query;
      if (query.isNotEmpty) {
        // Mock search results
        _totalSearchMatches = (query.length * 3) % 15 + 1;
        _currentSearchMatch = 1;
      } else {
        _totalSearchMatches = 0;
        _currentSearchMatch = 0;
      }
    });
  }

  void _navigateToNextMatch() {
    if (_totalSearchMatches > 0) {
      setState(() {
        _currentSearchMatch = _currentSearchMatch < _totalSearchMatches
            ? _currentSearchMatch + 1
            : 1;
      });
    }
  }

  void _navigateToPreviousMatch() {
    if (_totalSearchMatches > 0) {
      setState(() {
        _currentSearchMatch = _currentSearchMatch > 1
            ? _currentSearchMatch - 1
            : _totalSearchMatches;
      });
    }
  }

  // Page Navigation
  void _goToPage(int page) {
    if (page >= 1 && page <= _totalPages) {
      setState(() {
        _currentPage = page;
        _isBookmarked = _bookmarks.any((b) => b.pageNumber == page);
      });
      _closeThumbnailView();
      _closeBookmarkView();
      _showControls();
    }
  }

  // UI State Management
  void _toggleSearch() {
    setState(() {
      _isSearchVisible = !_isSearchVisible;
      if (!_isSearchVisible) {
        _searchQuery = "";
        _totalSearchMatches = 0;
        _currentSearchMatch = 0;
      }
    });
  }

  void _toggleThumbnailView() {
    setState(() {
      _isThumbnailVisible = !_isThumbnailVisible;
      if (_isThumbnailVisible) {
        _isBookmarkVisible = false;
      }
    });
  }

  void _closeThumbnailView() {
    setState(() {
      _isThumbnailVisible = false;
    });
  }

  void _toggleBookmarkView() {
    setState(() {
      _isBookmarkVisible = !_isBookmarkVisible;
      if (_isBookmarkVisible) {
        _isThumbnailVisible = false;
      }
    });
  }

  void _closeBookmarkView() {
    setState(() {
      _isBookmarkVisible = false;
    });
  }

  void _toggleNightMode() {
    setState(() {
      _isNightMode = !_isNightMode;
    });
    _showSuccessMessage(
        _isNightMode ? 'Night mode enabled' : 'Night mode disabled');
  }

  // Zoom Controls
  void _zoomIn() {
    setState(() {
      _zoomLevel = (_zoomLevel * 1.2).clamp(0.5, 3.0);
    });
  }

  void _zoomOut() {
    setState(() {
      _zoomLevel = (_zoomLevel / 1.2).clamp(0.5, 3.0);
    });
  }

  void _resetZoom() {
    setState(() {
      _zoomLevel = 1.0;
    });
  }

  void _fitToWidth() {
    setState(() {
      _zoomLevel = 1.2; // Mock fit to width
    });
  }

  // Utility Methods
  void _showSuccessMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _showErrorMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppTheme.lightTheme.colorScheme.error,
        duration: Duration(seconds: 3),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _isNightMode
          ? AppTheme.lightTheme.colorScheme.surface.withValues(alpha: 0.1)
          : AppTheme.lightTheme.colorScheme.surface,
      body: Stack(
        children: [
          // PDF Content Area
          GestureDetector(
            onTap: _toggleControls,
            onDoubleTap: _fitToWidth,
            child: Container(
              width: double.infinity,
              height: double.infinity,
              child: InteractiveViewer(
                minScale: 0.5,
                maxScale: 3.0,
                onInteractionUpdate: (details) {
                  _showControls();
                },
                child: Container(
                  padding: EdgeInsets.all(4.w),
                  child: _buildPdfContent(),
                ),
              ),
            ),
          ),

          // Top Toolbar
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            child: PdfToolbarWidget(
              documentTitle: _documentTitle,
              isVisible: _isToolbarVisible,
              onBackPressed: () => Navigator.pop(context),
              onDownloadPressed: _downloadDocument,
              onSharePressed: _shareDocument,
              onBookmarkPressed: _toggleBookmark,
              onSearchPressed: _toggleSearch,
              isBookmarked: _isBookmarked,
              isDownloaded: _isDownloaded,
            ),
          ),

          // Search Bar
          Positioned(
            top: _isToolbarVisible ? 12.h : 0,
            left: 0,
            right: 0,
            child: PdfSearchWidget(
              isVisible: _isSearchVisible,
              onSearchChanged: _performSearch,
              onPreviousMatch: _navigateToPreviousMatch,
              onNextMatch: _navigateToNextMatch,
              onCloseSearch: _toggleSearch,
              currentMatch: _currentSearchMatch,
              totalMatches: _totalSearchMatches,
            ),
          ),

          // Bottom Navigation
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: PdfNavigationWidget(
              currentPage: _currentPage,
              totalPages: _totalPages,
              isVisible: _isNavigationVisible,
              onPageChanged: _goToPage,
              onThumbnailPressed: _toggleThumbnailView,
              isNightMode: _isNightMode,
              onNightModeToggle: _toggleNightMode,
            ),
          ),

          // Thumbnail Grid Overlay
          if (_isThumbnailVisible)
            Positioned.fill(
              child: PdfThumbnailGridWidget(
                isVisible: _isThumbnailVisible,
                totalPages: _totalPages,
                currentPage: _currentPage,
                onPageSelected: _goToPage,
                onClose: _closeThumbnailView,
              ),
            ),

          // Bookmark Panel Overlay
          if (_isBookmarkVisible)
            Positioned.fill(
              child: PdfBookmarkWidget(
                isVisible: _isBookmarkVisible,
                bookmarks: _bookmarks,
                onBookmarkSelected: _goToPage,
                onBookmarkDeleted: _deleteBookmark,
                onClose: _closeBookmarkView,
              ),
            ),

          // Download Progress Indicator
          if (_isDownloading)
            Positioned.fill(
              child: Container(
                color: AppTheme.lightTheme.colorScheme.surface
                    .withValues(alpha: 0.8),
                child: Center(
                  child: Container(
                    padding: EdgeInsets.all(6.w),
                    decoration: BoxDecoration(
                      color: AppTheme.lightTheme.colorScheme.surface,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.lightTheme.colorScheme.shadow
                              .withValues(alpha: 0.2),
                          blurRadius: 8,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        CircularProgressIndicator(
                          color: AppTheme.lightTheme.colorScheme.primary,
                        ),
                        SizedBox(height: 2.h),
                        Text(
                          'Downloading Document...',
                          style: AppTheme.lightTheme.textTheme.titleMedium
                              ?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),

          // Floating Action Button for Bookmarks
          Positioned(
            right: 4.w,
            bottom: 20.h,
            child: FloatingActionButton(
              mini: true,
              onPressed: _toggleBookmarkView,
              backgroundColor: AppTheme.lightTheme.colorScheme.primary,
              child: CustomIconWidget(
                iconName: 'bookmark',
                color: AppTheme.lightTheme.colorScheme.onPrimary,
                size: 20,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPdfContent() {
    return Container(
      width: double.infinity,
      constraints: BoxConstraints(minHeight: 100.h),
      decoration: BoxDecoration(
        color: _isNightMode
            ? AppTheme.lightTheme.colorScheme.surface.withValues(alpha: 0.9)
            : Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
            color:
                AppTheme.lightTheme.colorScheme.shadow.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          // Page Header
          Container(
            width: double.infinity,
            padding: EdgeInsets.all(6.w),
            decoration: BoxDecoration(
              color: AppTheme.lightTheme.colorScheme.primary
                  .withValues(alpha: 0.05),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(8),
                topRight: Radius.circular(8),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Page $_currentPage of $_totalPages',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.primary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 1.h),
                Text(
                  _getCurrentPageTitle(),
                  style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.w700,
                    color: _isNightMode
                        ? AppTheme.lightTheme.colorScheme.onSurface
                            .withValues(alpha: 0.9)
                        : AppTheme.lightTheme.colorScheme.onSurface,
                  ),
                ),
              ],
            ),
          ),

          // Page Content
          Expanded(
            child: Container(
              width: double.infinity,
              padding: EdgeInsets.all(6.w),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _getCurrentPageContent(),
                    style: AppTheme.lightTheme.textTheme.bodyLarge?.copyWith(
                      height: 1.6,
                      color: _isNightMode
                          ? AppTheme.lightTheme.colorScheme.onSurface
                              .withValues(alpha: 0.8)
                          : AppTheme.lightTheme.colorScheme.onSurface,
                    ),
                  ),
                  SizedBox(height: 4.h),

                  // Mock agricultural content
                  _buildMockContent(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  String _getCurrentPageTitle() {
    if (_currentPage <= _pdfPages.length) {
      return _pdfPages[_currentPage - 1]["title"];
    }
    return "Chapter ${(_currentPage / 5).ceil()}: Advanced Techniques";
  }

  String _getCurrentPageContent() {
    if (_currentPage <= _pdfPages.length) {
      return _pdfPages[_currentPage - 1]["content"];
    }
    return "This section covers advanced organic farming techniques including sustainable practices, crop rotation methods, and natural pest management strategies that have been proven effective in various agricultural conditions.";
  }

  Widget _buildMockContent() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Mock diagram placeholder
        Container(
          width: double.infinity,
          height: 25.h,
          decoration: BoxDecoration(
            color:
                AppTheme.lightTheme.colorScheme.surface.withValues(alpha: 0.5),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: AppTheme.lightTheme.colorScheme.outline
                  .withValues(alpha: 0.3),
              width: 1,
            ),
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                CustomIconWidget(
                  iconName: 'agriculture',
                  color: AppTheme.lightTheme.colorScheme.primary
                      .withValues(alpha: 0.6),
                  size: 48,
                ),
                SizedBox(height: 2.h),
                Text(
                  'Agricultural Diagram',
                  style: AppTheme.lightTheme.textTheme.titleMedium?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.6),
                  ),
                ),
                Text(
                  'Figure ${_currentPage}.1',
                  style: AppTheme.lightTheme.textTheme.bodySmall?.copyWith(
                    color: AppTheme.lightTheme.colorScheme.onSurface
                        .withValues(alpha: 0.5),
                  ),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 3.h),

        // Mock bullet points
        ...List.generate(
            5,
            (index) => Padding(
                  padding: EdgeInsets.only(bottom: 1.h),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: 1.w,
                        height: 1.w,
                        margin: EdgeInsets.only(top: 1.h, right: 3.w),
                        decoration: BoxDecoration(
                          color: AppTheme.lightTheme.colorScheme.primary,
                          shape: BoxShape.circle,
                        ),
                      ),
                      Expanded(
                        child: Text(
                          _getMockBulletPoint(index),
                          style: AppTheme.lightTheme.textTheme.bodyMedium
                              ?.copyWith(
                            color: _isNightMode
                                ? AppTheme.lightTheme.colorScheme.onSurface
                                    .withValues(alpha: 0.8)
                                : AppTheme.lightTheme.colorScheme.onSurface,
                          ),
                        ),
                      ),
                    ],
                  ),
                )),
      ],
    );
  }

  String _getMockBulletPoint(int index) {
    final points = [
      "Maintain soil pH between 6.0 and 7.0 for optimal nutrient absorption",
      "Implement crop rotation every 3-4 seasons to prevent soil depletion",
      "Use organic compost and natural fertilizers to enhance soil fertility",
      "Monitor weather patterns and adjust irrigation schedules accordingly",
      "Regular pest inspection helps prevent major crop damage",
    ];
    return points[index % points.length];
  }
}

// Timer class for auto-hide functionality
class Timer {
  final Duration duration;
  final VoidCallback callback;
  late Future _future;

  Timer(this.duration, this.callback) {
    _future = Future.delayed(duration, callback);
  }

  void cancel() {
    // Timer cancellation would be handled by the Future
  }
}