import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/category_tab_widget.dart';
import './widgets/discussion_card_widget.dart';
import './widgets/discussion_filter_widget.dart';
import './widgets/new_discussion_dialog_widget.dart';
import './widgets/new_discussion_fab_widget.dart';
import './widgets/search_bar_widget.dart';

class FarmerDiscussionForum extends StatefulWidget {
  const FarmerDiscussionForum({super.key});

  @override
  State<FarmerDiscussionForum> createState() => _FarmerDiscussionForumState();
}

class _FarmerDiscussionForumState extends State<FarmerDiscussionForum>
    with TickerProviderStateMixin {
  final TextEditingController _searchController = TextEditingController();
  final ScrollController _scrollController = ScrollController();

  int _selectedCategoryIndex = 0;
  String _selectedSort = 'recent';
  bool _showOnlyFollowed = false;
  bool _isRefreshing = false;
  List<String> _recentSearches = [
    'Organic fertilizer',
    'Crop rotation',
    'Pest control'
  ];

  final List<String> _categories = [
    'All',
    'Crop Diseases',
    'Organic Methods',
    'Equipment',
    'Weather Discussions',
    'Success Stories',
  ];

  // Mock discussion data
  final List<Map<String, dynamic>> _allDiscussions = [
    {
      "id": 1,
      "title": "Best organic fertilizer for tomato plants?",
      "preview":
          "I'm looking for recommendations on organic fertilizers that work well for tomato cultivation. My current yield is not satisfactory and I want to switch to organic methods.",
      "category": "Organic Methods",
      "author": "Rajesh Kumar",
      "authorLocation": "Punjab, India",
      "timestamp": DateTime.now().subtract(Duration(minutes: 30)),
      "replyCount": 12,
      "likeCount": 8,
      "hasImage": true,
      "imageUrl":
          "https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg",
      "isFollowed": true,
    },
    {
      "id": 2,
      "title": "Dealing with aphid infestation on cotton crops",
      "preview":
          "My cotton field is severely affected by aphids. I've tried neem oil spray but the problem persists. Looking for effective organic solutions that won't harm beneficial insects.",
      "category": "Crop Diseases",
      "author": "Priya Sharma",
      "authorLocation": "Gujarat, India",
      "timestamp": DateTime.now().subtract(Duration(hours: 2)),
      "replyCount": 18,
      "likeCount": 15,
      "hasImage": true,
      "imageUrl":
          "https://images.pexels.com/photos/1459505/pexels-photo-1459505.jpeg",
      "isFollowed": false,
    },
    {
      "id": 3,
      "title": "New tractor recommendations under ₹8 lakhs",
      "preview":
          "Planning to buy a new tractor for my 10-acre farm. Need something reliable with good fuel efficiency. What are your experiences with different brands?",
      "category": "Equipment",
      "author": "Suresh Patel",
      "authorLocation": "Maharashtra, India",
      "timestamp": DateTime.now().subtract(Duration(hours: 4)),
      "replyCount": 25,
      "likeCount": 22,
      "hasImage": false,
      "isFollowed": true,
    },
    {
      "id": 4,
      "title": "Monsoon predictions for this season - your thoughts?",
      "preview":
          "Weather department is predicting normal monsoon this year. But local patterns seem different. What are you observing in your regions? How are you preparing?",
      "category": "Weather Discussions",
      "author": "Amit Singh",
      "authorLocation": "Uttar Pradesh, India",
      "timestamp": DateTime.now().subtract(Duration(hours: 6)),
      "replyCount": 31,
      "likeCount": 19,
      "hasImage": false,
      "isFollowed": false,
    },
    {
      "id": 5,
      "title": "Doubled my wheat yield with crop rotation!",
      "preview":
          "Last season I implemented a proper crop rotation system with legumes and saw amazing results. My wheat yield increased by 40%. Here's what I did and the exact process I followed.",
      "category": "Success Stories",
      "author": "Kavita Devi",
      "authorLocation": "Haryana, India",
      "timestamp": DateTime.now().subtract(Duration(hours: 8)),
      "replyCount": 42,
      "likeCount": 67,
      "hasImage": true,
      "imageUrl":
          "https://images.pexels.com/photos/2132180/pexels-photo-2132180.jpeg",
      "isFollowed": true,
    },
    {
      "id": 6,
      "title": "Drip irrigation setup cost and benefits",
      "preview":
          "Considering installing drip irrigation for my vegetable farm. What has been your experience with costs, water savings, and crop improvement? Any specific brand recommendations?",
      "category": "Equipment",
      "author": "Mohan Reddy",
      "authorLocation": "Andhra Pradesh, India",
      "timestamp": DateTime.now().subtract(Duration(hours: 12)),
      "replyCount": 16,
      "likeCount": 11,
      "hasImage": false,
      "isFollowed": false,
    },
    {
      "id": 7,
      "title": "Companion planting strategies that actually work",
      "preview":
          "Been experimenting with companion planting for 3 years now. Some combinations work amazingly well while others don't show much difference. Sharing my detailed observations.",
      "category": "Organic Methods",
      "author": "Deepak Joshi",
      "authorLocation": "Rajasthan, India",
      "timestamp": DateTime.now().subtract(Duration(days: 1)),
      "replyCount": 28,
      "likeCount": 34,
      "hasImage": true,
      "imageUrl":
          "https://images.pexels.com/photos/1301856/pexels-photo-1301856.jpeg",
      "isFollowed": true,
    },
    {
      "id": 8,
      "title": "Soil testing results interpretation help needed",
      "preview":
          "Got my soil test results but finding it difficult to understand what the numbers mean for my crop planning. Can someone help me interpret these values and suggest improvements?",
      "category": "General",
      "author": "Sunita Kumari",
      "authorLocation": "Bihar, India",
      "timestamp": DateTime.now().subtract(Duration(days: 2)),
      "replyCount": 14,
      "likeCount": 9,
      "hasImage": true,
      "imageUrl":
          "https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg",
      "isFollowed": false,
    },
  ];

  List<Map<String, dynamic>> get _filteredDiscussions {
    List<Map<String, dynamic>> filtered = List.from(_allDiscussions);

    // Filter by category
    if (_selectedCategoryIndex > 0) {
      final selectedCategory = _categories[_selectedCategoryIndex];
      filtered = filtered
          .where((discussion) => discussion["category"] == selectedCategory)
          .toList();
    }

    // Filter by search query
    if (_searchController.text.isNotEmpty) {
      final query = _searchController.text.toLowerCase();
      filtered = filtered
          .where((discussion) =>
              (discussion["title"] as String).toLowerCase().contains(query) ||
              (discussion["preview"] as String).toLowerCase().contains(query) ||
              (discussion["author"] as String).toLowerCase().contains(query) ||
              (discussion["category"] as String).toLowerCase().contains(query))
          .toList();
    }

    // Filter by followed
    if (_showOnlyFollowed) {
      filtered = filtered
          .where((discussion) => discussion["isFollowed"] == true)
          .toList();
    }

    // Sort discussions
    switch (_selectedSort) {
      case 'popular':
        filtered.sort(
            (a, b) => (b["likeCount"] as int).compareTo(a["likeCount"] as int));
        break;
      case 'replies':
        filtered.sort((a, b) =>
            (b["replyCount"] as int).compareTo(a["replyCount"] as int));
        break;
      case 'recent':
      default:
        filtered.sort((a, b) =>
            (b["timestamp"] as DateTime).compareTo(a["timestamp"] as DateTime));
        break;
    }

    return filtered;
  }

  @override
  void dispose() {
    _searchController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _refreshDiscussions() async {
    setState(() => _isRefreshing = true);

    // Simulate API call
    await Future.delayed(Duration(seconds: 2));

    setState(() => _isRefreshing = false);
  }

  void _onSearchChanged(String query) {
    setState(() {});

    // Add to recent searches if query is meaningful
    if (query.length > 2 && !_recentSearches.contains(query)) {
      setState(() {
        _recentSearches.insert(0, query);
        if (_recentSearches.length > 10) {
          _recentSearches = _recentSearches.take(10).toList();
        }
      });
    }
  }

  void _onRecentSearchTap(String search) {
    _searchController.text = search;
    setState(() {});
    FocusScope.of(context).unfocus();
  }

  void _onDiscussionTap(Map<String, dynamic> discussion) {
    // Navigate to discussion detail screen
    // In real implementation: Navigator.pushNamed(context, '/discussion-detail', arguments: discussion);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Opening discussion: ${discussion["title"]}'),
        duration: Duration(seconds: 2),
      ),
    );
  }

  void _showNewDiscussionDialog() {
    showDialog(
      context: context,
      builder: (context) => NewDiscussionDialogWidget(
        onSubmit: (discussionData) {
          // In real implementation, this would submit to API
          setState(() {
            _allDiscussions.insert(0, {
              ...discussionData,
              "id": _allDiscussions.length + 1,
              "author": "Current User",
              "authorLocation": "Your Location",
              "replyCount": 0,
              "likeCount": 0,
              "isFollowed": false,
              "preview": (discussionData["content"] as String).length > 150
                  ? "${(discussionData["content"] as String).substring(0, 150)}..."
                  : discussionData["content"],
              "imageUrl": discussionData["hasImage"] == true
                  ? "https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg"
                  : null,
            });
          });

          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Discussion posted successfully!'),
              backgroundColor: AppTheme.lightTheme.colorScheme.primary,
            ),
          );
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final filteredDiscussions = _filteredDiscussions;

    return Scaffold(
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        title: Text(
          'Discussion Forum',
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
          ),
        ),
        centerTitle: true,
        backgroundColor: theme.colorScheme.primary,
        foregroundColor: theme.colorScheme.onPrimary,
        elevation: 2,
        actions: [
          IconButton(
            onPressed: () =>
                Navigator.pushNamed(context, '/user-profile-settings'),
            icon: CustomIconWidget(
              iconName: 'account_circle',
              size: 6.w,
              color: theme.colorScheme.onPrimary,
            ),
            tooltip: 'Profile',
          ),
        ],
      ),
      body: Column(
        children: [
          // Search bar
          SearchBarWidget(
            controller: _searchController,
            onChanged: _onSearchChanged,
            onSearchPressed: () => FocusScope.of(context).unfocus(),
            recentSearches: _recentSearches,
            onRecentSearchTap: _onRecentSearchTap,
          ),

          // Category tabs
          CategoryTabWidget(
            categories: _categories,
            selectedIndex: _selectedCategoryIndex,
            onCategorySelected: (index) {
              setState(() => _selectedCategoryIndex = index);
            },
          ),

          // Filter options
          DiscussionFilterWidget(
            selectedSort: _selectedSort,
            onSortChanged: (sort) => setState(() => _selectedSort = sort),
            showOnlyFollowed: _showOnlyFollowed,
            onFollowedToggle: (value) =>
                setState(() => _showOnlyFollowed = value),
          ),

          // Discussion list
          Expanded(
            child: RefreshIndicator(
              onRefresh: _refreshDiscussions,
              color: theme.colorScheme.primary,
              child: filteredDiscussions.isEmpty
                  ? _buildEmptyState(theme)
                  : ListView.builder(
                      controller: _scrollController,
                      physics: AlwaysScrollableScrollPhysics(),
                      itemCount: filteredDiscussions.length,
                      itemBuilder: (context, index) {
                        final discussion = filteredDiscussions[index];
                        return DiscussionCardWidget(
                          discussion: discussion,
                          onTap: () => _onDiscussionTap(discussion),
                        );
                      },
                    ),
            ),
          ),
        ],
      ),
      floatingActionButton: NewDiscussionFabWidget(
        onPressed: _showNewDiscussionDialog,
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          boxShadow: [
            BoxShadow(
              color: theme.colorScheme.shadow.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: Offset(0, -2),
            ),
          ],
        ),
        child: SafeArea(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _buildBottomNavItem(
                  context,
                  'agriculture',
                  'Crops',
                  '/crop-price-search',
                  false,
                ),
                _buildBottomNavItem(
                  context,
                  'wb_sunny',
                  'Weather',
                  '/weather-forecast',
                  false,
                ),
                _buildBottomNavItem(
                  context,
                  'account_balance',
                  'Schemes',
                  '/government-schemes-browser',
                  false,
                ),
                _buildBottomNavItem(
                  context,
                  'forum',
                  'Forum',
                  '/farmer-discussion-forum',
                  true,
                ),
                _buildBottomNavItem(
                  context,
                  'person',
                  'Profile',
                  '/user-profile-settings',
                  false,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildBottomNavItem(
    BuildContext context,
    String iconName,
    String label,
    String route,
    bool isSelected,
  ) {
    final theme = Theme.of(context);

    return GestureDetector(
      onTap: () {
        if (!isSelected) {
          Navigator.pushNamed(context, route);
        }
      },
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 1.h),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            CustomIconWidget(
              iconName: iconName,
              size: 6.w,
              color: isSelected
                  ? theme.colorScheme.primary
                  : theme.colorScheme.onSurface.withValues(alpha: 0.6),
            ),
            SizedBox(height: 0.5.h),
            Text(
              label,
              style: theme.textTheme.labelSmall?.copyWith(
                color: isSelected
                    ? theme.colorScheme.primary
                    : theme.colorScheme.onSurface.withValues(alpha: 0.6),
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(ThemeData theme) {
    return Center(
      child: Padding(
        padding: EdgeInsets.all(8.w),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CustomIconWidget(
              iconName: 'forum',
              size: 20.w,
              color: theme.colorScheme.onSurface.withValues(alpha: 0.3),
            ),
            SizedBox(height: 3.h),
            Text(
              _searchController.text.isNotEmpty
                  ? 'No discussions found'
                  : 'No discussions yet',
              style: theme.textTheme.titleMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                fontWeight: FontWeight.w500,
              ),
            ),
            SizedBox(height: 1.h),
            Text(
              _searchController.text.isNotEmpty
                  ? 'Try adjusting your search or filters'
                  : 'Be the first to start a discussion!',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurface.withValues(alpha: 0.5),
              ),
              textAlign: TextAlign.center,
            ),
            if (_searchController.text.isEmpty) ...[
              SizedBox(height: 3.h),
              ElevatedButton.icon(
                onPressed: _showNewDiscussionDialog,
                icon: CustomIconWidget(
                  iconName: 'add',
                  size: 5.w,
                  color: theme.colorScheme.onPrimary,
                ),
                label: Text('Start Discussion'),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
