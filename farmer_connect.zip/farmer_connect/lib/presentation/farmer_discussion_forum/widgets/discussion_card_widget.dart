import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';

class DiscussionCardWidget extends StatelessWidget {
  final Map<String, dynamic> discussion;
  final VoidCallback? onTap;

  const DiscussionCardWidget({
    super.key,
    required this.discussion,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Card(
      margin: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: EdgeInsets.all(4.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Header with category and timestamp
              Row(
                children: [
                  Container(
                    padding:
                        EdgeInsets.symmetric(horizontal: 2.w, vertical: 0.5.h),
                    decoration: BoxDecoration(
                      color: _getCategoryColor(
                          discussion["category"] as String? ?? "General"),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      discussion["category"] as String? ?? "General",
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: Colors.white,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                  Spacer(),
                  Text(
                    _formatTimestamp(
                        discussion["timestamp"] as DateTime? ?? DateTime.now()),
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 1.h),

              // Title
              Text(
                discussion["title"] as String? ?? "Untitled Discussion",
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              SizedBox(height: 1.h),

              // Preview content
              Text(
                discussion["preview"] as String? ?? "",
                style: theme.textTheme.bodyMedium?.copyWith(
                  color: theme.colorScheme.onSurface.withValues(alpha: 0.8),
                ),
                maxLines: 3,
                overflow: TextOverflow.ellipsis,
              ),

              // Image thumbnail if available
              if (discussion["hasImage"] == true) ...[
                SizedBox(height: 1.h),
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: CustomImageWidget(
                    imageUrl: discussion["imageUrl"] as String? ??
                        "https://images.pexels.com/photos/1595104/pexels-photo-1595104.jpeg",
                    width: double.infinity,
                    height: 15.h,
                    fit: BoxFit.cover,
                  ),
                ),
              ],

              SizedBox(height: 1.5.h),

              // Footer with author and engagement metrics
              Row(
                children: [
                  // Author info
                  CircleAvatar(
                    radius: 2.w,
                    backgroundColor:
                        theme.colorScheme.primary.withValues(alpha: 0.1),
                    child: CustomIconWidget(
                      iconName: 'person',
                      size: 3.w,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  SizedBox(width: 2.w),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          discussion["author"] as String? ?? "Anonymous",
                          style: theme.textTheme.bodySmall?.copyWith(
                            fontWeight: FontWeight.w500,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                        if (discussion["authorLocation"] != null)
                          Text(
                            discussion["authorLocation"] as String,
                            style: theme.textTheme.labelSmall?.copyWith(
                              color: theme.colorScheme.onSurface
                                  .withValues(alpha: 0.6),
                            ),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                          ),
                      ],
                    ),
                  ),

                  // Engagement metrics
                  Row(
                    children: [
                      CustomIconWidget(
                        iconName: 'chat_bubble_outline',
                        size: 4.w,
                        color:
                            theme.colorScheme.onSurface.withValues(alpha: 0.6),
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        "${discussion["replyCount"] ?? 0}",
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurface
                              .withValues(alpha: 0.6),
                        ),
                      ),
                      SizedBox(width: 3.w),
                      CustomIconWidget(
                        iconName: 'thumb_up_outlined',
                        size: 4.w,
                        color:
                            theme.colorScheme.onSurface.withValues(alpha: 0.6),
                      ),
                      SizedBox(width: 1.w),
                      Text(
                        "${discussion["likeCount"] ?? 0}",
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: theme.colorScheme.onSurface
                              .withValues(alpha: 0.6),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getCategoryColor(String category) {
    switch (category.toLowerCase()) {
      case 'crop diseases':
        return Colors.red.shade400;
      case 'organic methods':
        return Colors.green.shade400;
      case 'equipment':
        return Colors.blue.shade400;
      case 'weather discussions':
        return Colors.orange.shade400;
      case 'success stories':
        return Colors.purple.shade400;
      default:
        return Colors.grey.shade400;
    }
  }

  String _formatTimestamp(DateTime timestamp) {
    final now = DateTime.now();
    final difference = now.difference(timestamp);

    if (difference.inMinutes < 60) {
      return "${difference.inMinutes}m ago";
    } else if (difference.inHours < 24) {
      return "${difference.inHours}h ago";
    } else if (difference.inDays < 7) {
      return "${difference.inDays}d ago";
    } else {
      return "${timestamp.day}/${timestamp.month}/${timestamp.year}";
    }
  }
}
