import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../../core/app_export.dart';
import '../../../widgets/custom_icon_widget.dart';

class DiscussionFilterWidget extends StatelessWidget {
  final String selectedSort;
  final ValueChanged<String> onSortChanged;
  final bool showOnlyFollowed;
  final ValueChanged<bool> onFollowedToggle;

  const DiscussionFilterWidget({
    super.key,
    required this.selectedSort,
    required this.onSortChanged,
    required this.showOnlyFollowed,
    required this.onFollowedToggle,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 4.w, vertical: 1.h),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        border: Border(
          bottom: BorderSide(
            color: theme.colorScheme.outline.withValues(alpha: 0.2),
            width: 1,
          ),
        ),
      ),
      child: Row(
        children: [
          // Sort dropdown
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
              decoration: BoxDecoration(
                border: Border.all(
                  color: theme.colorScheme.outline.withValues(alpha: 0.3),
                  width: 1,
                ),
                borderRadius: BorderRadius.circular(8),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: selectedSort,
                  onChanged: (value) =>
                      value != null ? onSortChanged(value) : null,
                  icon: CustomIconWidget(
                    iconName: 'keyboard_arrow_down',
                    size: 5.w,
                    color: theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                  style: theme.textTheme.bodyMedium,
                  items: [
                    DropdownMenuItem(
                      value: 'recent',
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'access_time',
                            size: 4.w,
                            color: theme.colorScheme.onSurface
                                .withValues(alpha: 0.6),
                          ),
                          SizedBox(width: 2.w),
                          Text('Most Recent'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'popular',
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'trending_up',
                            size: 4.w,
                            color: theme.colorScheme.onSurface
                                .withValues(alpha: 0.6),
                          ),
                          SizedBox(width: 2.w),
                          Text('Most Popular'),
                        ],
                      ),
                    ),
                    DropdownMenuItem(
                      value: 'replies',
                      child: Row(
                        children: [
                          CustomIconWidget(
                            iconName: 'chat_bubble_outline',
                            size: 4.w,
                            color: theme.colorScheme.onSurface
                                .withValues(alpha: 0.6),
                          ),
                          SizedBox(width: 2.w),
                          Text('Most Replies'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          SizedBox(width: 3.w),

          // Followed toggle
          Container(
            padding: EdgeInsets.symmetric(horizontal: 3.w, vertical: 1.h),
            decoration: BoxDecoration(
              color: showOnlyFollowed
                  ? theme.colorScheme.primary.withValues(alpha: 0.1)
                  : Colors.transparent,
              border: Border.all(
                color: showOnlyFollowed
                    ? theme.colorScheme.primary
                    : theme.colorScheme.outline.withValues(alpha: 0.3),
                width: 1,
              ),
              borderRadius: BorderRadius.circular(8),
            ),
            child: InkWell(
              onTap: () => onFollowedToggle(!showOnlyFollowed),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  CustomIconWidget(
                    iconName: showOnlyFollowed ? 'favorite' : 'favorite_border',
                    size: 4.w,
                    color: showOnlyFollowed
                        ? theme.colorScheme.primary
                        : theme.colorScheme.onSurface.withValues(alpha: 0.6),
                  ),
                  SizedBox(width: 2.w),
                  Text(
                    'Following',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: showOnlyFollowed
                          ? theme.colorScheme.primary
                          : theme.colorScheme.onSurface.withValues(alpha: 0.6),
                      fontWeight:
                          showOnlyFollowed ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
