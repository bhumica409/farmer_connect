import 'package:flutter/material.dart';
import 'package:sizer/sizer.dart';

import '../../core/app_export.dart';
import './widgets/language_selector_widget.dart';
import './widgets/settings_item.dart';
import './widgets/settings_section.dart';
import './widgets/storage_usage_widget.dart';
import './widgets/toggle_settings_item.dart';
import './widgets/user_info_card.dart';

class UserProfileSettings extends StatefulWidget {
  const UserProfileSettings({super.key});

  @override
  State<UserProfileSettings> createState() => _UserProfileSettingsState();
}

class _UserProfileSettingsState extends State<UserProfileSettings> {
  // Mock user data
  final Map<String, dynamic> userInfo = {
    "name": "Rajesh Kumar",
    "location": "Pune, Maharashtra",
    "experience": 12,
    "profilePhoto":
        "https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=400",
  };

  // Mock personal information
  final Map<String, dynamic> personalInfo = {
    "farmSize": "5.2 acres",
    "primaryCrops": ["Rice", "Wheat", "Sugarcane"],
    "organicCertified": true,
    "selectedLanguage": "en",
  };

  // Mock notification preferences
  Map<String, bool> notificationSettings = {
    "priceAlerts": true,
    "weatherWarnings": true,
    "schemeUpdates": false,
    "forumActivity": true,
  };

  // Mock location settings
  final Map<String, dynamic> locationSettings = {
    "savedLocations": ["Pune Farm", "Nashik Field"],
    "gpsAccuracy": "High",
    "autoLocation": true,
  };

  // Mock privacy settings
  Map<String, bool> privacySettings = {
    "profileVisible": true,
    "chatAvailable": true,
    "dataSharing": false,
  };

  // Mock app preferences
  Map<String, dynamic> appPreferences = {
    "offlineContent": true,
    "downloadQuality": "Medium",
    "autoDownload": false,
  };

  // Mock storage data
  final Map<String, dynamic> storageData = {
    "usedMB": 1536, // 1.5 GB
    "totalMB": 4096, // 4 GB
    "breakdown": [
      {
        "type": "Downloaded PDFs",
        "sizeMB": 768,
        "color": AppTheme.lightTheme.colorScheme.primary,
      },
      {
        "type": "Cached Images",
        "sizeMB": 512,
        "color": AppTheme.lightTheme.colorScheme.secondary,
      },
      {
        "type": "App Data",
        "sizeMB": 256,
        "color": Colors.orange,
      },
    ],
  };

  // Available languages
  final List<Map<String, dynamic>> languages = [
    {"code": "en", "name": "English", "flag": "🇺🇸"},
    {"code": "hi", "name": "हिन्दी", "flag": "🇮🇳"},
    {"code": "mr", "name": "मराठी", "flag": "🇮🇳"},
    {"code": "te", "name": "తెలుగు", "flag": "🇮🇳"},
    {"code": "ta", "name": "தமிழ்", "flag": "🇮🇳"},
    {"code": "kn", "name": "ಕನ್ನಡ", "flag": "🇮🇳"},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.lightTheme.colorScheme.surface,
      appBar: AppBar(
        title: Text(
          "Profile Settings",
          style: AppTheme.lightTheme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.w600,
            color: AppTheme.lightTheme.colorScheme.onPrimary,
          ),
        ),
        backgroundColor: AppTheme.lightTheme.colorScheme.primary,
        foregroundColor: AppTheme.lightTheme.colorScheme.onPrimary,
        elevation: 2,
        centerTitle: true,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: CustomIconWidget(
            iconName: 'arrow_back_ios',
            color: AppTheme.lightTheme.colorScheme.onPrimary,
            size: 20,
          ),
        ),
      ),
      body: SingleChildScrollView(
        physics: BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 2.h),

            // User Information Card
            UserInfoCard(
              userInfo: userInfo,
              onEditPressed: _showEditProfileDialog,
            ),

            SizedBox(height: 2.h),

            // Personal Information Section
            SettingsSection(
              title: "Personal Information",
              children: [
                SettingsItem(
                  iconName: 'landscape',
                  title: "Farm Size",
                  subtitle: personalInfo["farmSize"] as String,
                  onTap: () => _showFarmSizeDialog(),
                ),
                SettingsItem(
                  iconName: 'grass',
                  title: "Primary Crops",
                  subtitle:
                      (personalInfo["primaryCrops"] as List<String>).join(", "),
                  onTap: () => _showCropSelectionDialog(),
                ),
                ToggleSettingsItem(
                  iconName: 'eco',
                  title: "Organic Certification",
                  subtitle: "Display organic farming badge",
                  value: personalInfo["organicCertified"] as bool,
                  onChanged: (value) {
                    setState(() {
                      personalInfo["organicCertified"] = value;
                    });
                  },
                ),
                Padding(
                  padding: EdgeInsets.symmetric(vertical: 1.h),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            width: 10.w,
                            height: 10.w,
                            decoration: BoxDecoration(
                              color: AppTheme.lightTheme.colorScheme.primary
                                  .withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: Center(
                              child: CustomIconWidget(
                                iconName: 'language',
                                color: AppTheme.lightTheme.colorScheme.primary,
                                size: 20,
                              ),
                            ),
                          ),
                          SizedBox(width: 3.w),
                          Expanded(
                            child: Text(
                              "Preferred Language",
                              style: AppTheme.lightTheme.textTheme.bodyLarge
                                  ?.copyWith(
                                fontWeight: FontWeight.w500,
                                color:
                                    AppTheme.lightTheme.colorScheme.onSurface,
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 1.h),
                      LanguageSelectorWidget(
                        selectedLanguage:
                            personalInfo["selectedLanguage"] as String,
                        languages: languages,
                        onLanguageChanged: (value) {
                          setState(() {
                            personalInfo["selectedLanguage"] = value;
                          });
                                                },
                      ),
                    ],
                  ),
                ),
              ],
            ),

            // Notification Preferences Section
            SettingsSection(
              title: "Notification Preferences",
              children: [
                ToggleSettingsItem(
                  iconName: 'trending_up',
                  title: "Price Alerts",
                  subtitle: "Get notified about crop price changes",
                  value: notificationSettings["priceAlerts"]!,
                  onChanged: (value) {
                    setState(() {
                      notificationSettings["priceAlerts"] = value;
                    });
                  },
                ),
                ToggleSettingsItem(
                  iconName: 'wb_sunny',
                  title: "Weather Warnings",
                  subtitle: "Receive severe weather alerts",
                  value: notificationSettings["weatherWarnings"]!,
                  onChanged: (value) {
                    setState(() {
                      notificationSettings["weatherWarnings"] = value;
                    });
                  },
                ),
                ToggleSettingsItem(
                  iconName: 'account_balance',
                  title: "Scheme Updates",
                  subtitle: "New government schemes and subsidies",
                  value: notificationSettings["schemeUpdates"]!,
                  onChanged: (value) {
                    setState(() {
                      notificationSettings["schemeUpdates"] = value;
                    });
                  },
                ),
                ToggleSettingsItem(
                  iconName: 'forum',
                  title: "Forum Activity",
                  subtitle: "Replies and mentions in discussions",
                  value: notificationSettings["forumActivity"]!,
                  onChanged: (value) {
                    setState(() {
                      notificationSettings["forumActivity"] = value;
                    });
                  },
                  showDivider: false,
                ),
              ],
            ),

            // Location Settings Section
            SettingsSection(
              title: "Location Settings",
              children: [
                SettingsItem(
                  iconName: 'location_on',
                  title: "Saved Farm Locations",
                  subtitle:
                      "${(locationSettings["savedLocations"] as List<String>).length} locations saved",
                  onTap: () => _showLocationManagementDialog(),
                ),
                SettingsItem(
                  iconName: 'gps_fixed',
                  title: "GPS Accuracy",
                  subtitle: locationSettings["gpsAccuracy"] as String,
                  onTap: () => _showGpsAccuracyDialog(),
                  showDivider: false,
                ),
              ],
            ),

            // Privacy Controls Section
            SettingsSection(
              title: "Privacy Controls",
              children: [
                ToggleSettingsItem(
                  iconName: 'visibility',
                  title: "Profile Visibility",
                  subtitle: "Show profile in farmer directory",
                  value: privacySettings["profileVisible"]!,
                  onChanged: (value) {
                    setState(() {
                      privacySettings["profileVisible"] = value;
                    });
                  },
                ),
                ToggleSettingsItem(
                  iconName: 'chat',
                  title: "Chat Availability",
                  subtitle: "Allow other farmers to message you",
                  value: privacySettings["chatAvailable"]!,
                  onChanged: (value) {
                    setState(() {
                      privacySettings["chatAvailable"] = value;
                    });
                  },
                ),
                ToggleSettingsItem(
                  iconName: 'share',
                  title: "Data Sharing",
                  subtitle: "Share farming data with agricultural programs",
                  value: privacySettings["dataSharing"]!,
                  onChanged: (value) {
                    setState(() {
                      privacySettings["dataSharing"] = value;
                    });
                  },
                  showDivider: false,
                ),
              ],
            ),

            // App Preferences Section
            SettingsSection(
              title: "App Preferences",
              children: [
                ToggleSettingsItem(
                  iconName: 'offline_pin',
                  title: "Offline Content",
                  subtitle: "Download content for offline access",
                  value: appPreferences["offlineContent"] as bool,
                  onChanged: (value) {
                    setState(() {
                      appPreferences["offlineContent"] = value;
                    });
                  },
                ),
                SettingsItem(
                  iconName: 'high_quality',
                  title: "Download Quality",
                  subtitle: appPreferences["downloadQuality"] as String,
                  onTap: () => _showDownloadQualityDialog(),
                ),
                StorageUsageWidget(
                  storageData: storageData,
                  onCleanupPressed: _showStorageCleanupDialog,
                ),
              ],
            ),

            // Account Section
            SettingsSection(
              title: "Account",
              children: [
                SettingsItem(
                  iconName: 'lock',
                  title: "Change Password",
                  subtitle: "Update your account password",
                  onTap: () => _showChangePasswordDialog(),
                ),
                SettingsItem(
                  iconName: 'fingerprint',
                  title: "Biometric Authentication",
                  subtitle: "Use fingerprint or face unlock",
                  onTap: () => _showBiometricSetupDialog(),
                ),
                SettingsItem(
                  iconName: 'backup',
                  title: "Backup & Sync",
                  subtitle: "Sync settings across devices",
                  onTap: () => _showBackupSyncDialog(),
                ),
                SettingsItem(
                  iconName: 'delete_forever',
                  title: "Delete Account",
                  subtitle: "Permanently delete your account and data",
                  onTap: () => _showDeleteAccountDialog(),
                  showDivider: false,
                ),
              ],
            ),

            // Support Section
            SettingsSection(
              title: "Support & Information",
              children: [
                SettingsItem(
                  iconName: 'help',
                  title: "FAQ",
                  subtitle: "Frequently asked questions",
                  onTap: () => _navigateToFAQ(),
                ),
                SettingsItem(
                  iconName: 'contact_support',
                  title: "Contact Support",
                  subtitle: "Get help from agricultural extension services",
                  onTap: () => _showContactSupportDialog(),
                ),
                SettingsItem(
                  iconName: 'feedback',
                  title: "Send Feedback",
                  subtitle: "Help us improve the app",
                  onTap: () => _showFeedbackDialog(),
                ),
                SettingsItem(
                  iconName: 'info',
                  title: "App Version",
                  subtitle: "Version 2.1.0 (Build 24082024)",
                  showDivider: false,
                ),
              ],
            ),

            // Legal Section
            SettingsSection(
              title: "Legal",
              children: [
                SettingsItem(
                  iconName: 'description',
                  title: "Terms of Service",
                  subtitle: "Read our terms and conditions",
                  onTap: () => _navigateToTerms(),
                ),
                SettingsItem(
                  iconName: 'privacy_tip',
                  title: "Privacy Policy",
                  subtitle: "How we handle your data",
                  onTap: () => _navigateToPrivacyPolicy(),
                  showDivider: false,
                ),
              ],
            ),

            SizedBox(height: 4.h),
          ],
        ),
      ),
    );
  }

  void _showEditProfileDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Edit Profile"),
        content:
            Text("Profile editing functionality will be implemented here."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  void _showFarmSizeDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Update Farm Size"),
        content: TextField(
          decoration: InputDecoration(
            labelText: "Farm Size (acres)",
            hintText: "Enter your farm size",
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Save"),
          ),
        ],
      ),
    );
  }

  void _showCropSelectionDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Select Primary Crops"),
        content: Text("Crop selection interface will be implemented here."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  void _showLocationManagementDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Manage Farm Locations"),
        content:
            Text("Location management interface will be implemented here."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  void _showGpsAccuracyDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("GPS Accuracy Settings"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<String>(
              title: Text("High (More battery usage)"),
              value: "High",
              groupValue: locationSettings["gpsAccuracy"],
              onChanged: (value) {
                setState(() {
                  locationSettings["gpsAccuracy"] = value;
                });
                Navigator.pop(context);
              },
            ),
            RadioListTile<String>(
              title: Text("Medium (Balanced)"),
              value: "Medium",
              groupValue: locationSettings["gpsAccuracy"],
              onChanged: (value) {
                setState(() {
                  locationSettings["gpsAccuracy"] = value;
                });
                Navigator.pop(context);
              },
            ),
            RadioListTile<String>(
              title: Text("Low (Battery saver)"),
              value: "Low",
              groupValue: locationSettings["gpsAccuracy"],
              onChanged: (value) {
                setState(() {
                  locationSettings["gpsAccuracy"] = value;
                });
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showDownloadQualityDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Download Quality"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            RadioListTile<String>(
              title: Text("High (Better quality, more storage)"),
              value: "High",
              groupValue: appPreferences["downloadQuality"],
              onChanged: (value) {
                setState(() {
                  appPreferences["downloadQuality"] = value;
                });
                Navigator.pop(context);
              },
            ),
            RadioListTile<String>(
              title: Text("Medium (Balanced)"),
              value: "Medium",
              groupValue: appPreferences["downloadQuality"],
              onChanged: (value) {
                setState(() {
                  appPreferences["downloadQuality"] = value;
                });
                Navigator.pop(context);
              },
            ),
            RadioListTile<String>(
              title: Text("Low (Faster downloads, less storage)"),
              value: "Low",
              groupValue: appPreferences["downloadQuality"],
              onChanged: (value) {
                setState(() {
                  appPreferences["downloadQuality"] = value;
                });
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showStorageCleanupDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Clean Up Storage"),
        content: Text(
            "This will remove cached images and temporary files. Downloaded PDFs will be preserved."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Storage cleaned successfully")),
              );
            },
            child: Text("Clean Up"),
          ),
        ],
      ),
    );
  }

  void _showChangePasswordDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Change Password"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                labelText: "Current Password",
              ),
            ),
            SizedBox(height: 2.h),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                labelText: "New Password",
              ),
            ),
            SizedBox(height: 2.h),
            TextField(
              obscureText: true,
              decoration: InputDecoration(
                labelText: "Confirm New Password",
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Update"),
          ),
        ],
      ),
    );
  }

  void _showBiometricSetupDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Biometric Authentication"),
        content: Text(
            "Enable fingerprint or face unlock for quick access to your account."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Enable"),
          ),
        ],
      ),
    );
  }

  void _showBackupSyncDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Backup & Sync"),
        content:
            Text("Sync your settings and preferences across all your devices."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Enable Sync"),
          ),
        ],
      ),
    );
  }

  void _showDeleteAccountDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Delete Account"),
        content: Text(
            "This action cannot be undone. All your data will be permanently deleted."),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.lightTheme.colorScheme.error,
            ),
            child: Text("Delete Account"),
          ),
        ],
      ),
    );
  }

  void _navigateToFAQ() {
    Navigator.pushNamed(context, '/pdf-document-viewer');
  }

  void _showContactSupportDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Contact Support"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Email: support@farmerconnect.gov.in"),
            SizedBox(height: 1.h),
            Text("Phone: 1800-123-4567"),
            SizedBox(height: 1.h),
            Text("Working Hours: 9 AM - 6 PM"),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Close"),
          ),
        ],
      ),
    );
  }

  void _showFeedbackDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Send Feedback"),
        content: TextField(
          maxLines: 4,
          decoration: InputDecoration(
            hintText: "Tell us how we can improve...",
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text("Feedback sent successfully")),
              );
            },
            child: Text("Send"),
          ),
        ],
      ),
    );
  }

  void _navigateToTerms() {
    Navigator.pushNamed(context, '/pdf-document-viewer');
  }

  void _navigateToPrivacyPolicy() {
    Navigator.pushNamed(context, '/pdf-document-viewer');
  }
}
